import { useState, useEffect, useCallback } from "react";

export interface CryptoAsset {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  marketCap: number;
  volume24h: number;
  icon: string;
  color: string;
  bgColor: string;
}

const CRYPTO_CONFIG: Record<string, { icon: string; color: string; bgColor: string }> = {
  bitcoin: {
    icon: "₿",
    color: "#f7931a",
    bgColor: "#f7931a",
  },
  ethereum: {
    icon: "Ξ",
    color: "#627eea",
    bgColor: "#627eea",
  },
  solana: {
    icon: "◎",
    color: "#9945ff",
    bgColor: "#9945ff",
  },
  tether: {
    icon: "₮",
    color: "#26a17b",
    bgColor: "#26a17b",
  },
  "usd-coin": {
    icon: "$",
    color: "#2775ca",
    bgColor: "#2775ca",
  },
  "binancecoin": {
    icon: "B",
    color: "#f3ba2f",
    bgColor: "#f3ba2f",
  },
  "ripple": {
    icon: "✕",
    color: "#346aa9",
    bgColor: "#346aa9",
  },
  "cardano": {
    icon: "₳",
    color: "#0d1e2d",
    bgColor: "#0033ad",
  },
};

const COIN_IDS = Object.keys(CRYPTO_CONFIG).join(",");

export function useCryptoPrices() {
  const [assets, setAssets] = useState<CryptoAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchPrices = useCallback(async () => {
    try {
      const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${COIN_IDS}&order=market_cap_desc&per_page=20&page=1&sparkline=false&price_change_percentage=24h`;
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch prices");
      const data = await response.json();

      const mapped: CryptoAsset[] = data.map((coin: any) => {
        const config = CRYPTO_CONFIG[coin.id] || {
          icon: coin.symbol.toUpperCase().charAt(0),
          color: "#6366f1",
          bgColor: "#6366f1",
        };
        return {
          id: coin.id,
          symbol: coin.symbol.toUpperCase(),
          name: coin.name,
          price: coin.current_price,
          change24h: coin.price_change_percentage_24h ?? 0,
          marketCap: coin.market_cap,
          volume24h: coin.total_volume,
          icon: config.icon,
          color: config.color,
          bgColor: config.bgColor,
        };
      });

      setAssets(mapped);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      setError("Unable to fetch live prices. Showing cached data.");
      // Fallback static data so UI is never empty
      if (assets.length === 0) {
        setAssets([
          { id: "bitcoin", symbol: "BTC", name: "Bitcoin", price: 87000, change24h: 1.2, marketCap: 1700000000000, volume24h: 35000000000, icon: "₿", color: "#f7931a", bgColor: "#f7931a" },
          { id: "ethereum", symbol: "ETH", name: "Ethereum", price: 2050, change24h: -0.8, marketCap: 247000000000, volume24h: 12000000000, icon: "Ξ", color: "#627eea", bgColor: "#627eea" },
          { id: "solana", symbol: "SOL", name: "Solana", price: 135, change24h: 2.4, marketCap: 62000000000, volume24h: 3500000000, icon: "◎", color: "#9945ff", bgColor: "#9945ff" },
          { id: "tether", symbol: "USDT", name: "Tether", price: 1.00, change24h: 0.01, marketCap: 140000000000, volume24h: 80000000000, icon: "₮", color: "#26a17b", bgColor: "#26a17b" },
          { id: "binancecoin", symbol: "BNB", name: "BNB", price: 580, change24h: 0.5, marketCap: 84000000000, volume24h: 1800000000, icon: "B", color: "#f3ba2f", bgColor: "#f3ba2f" },
          { id: "ripple", symbol: "XRP", name: "XRP", price: 2.10, change24h: -1.3, marketCap: 120000000000, volume24h: 6000000000, icon: "✕", color: "#346aa9", bgColor: "#346aa9" },
        ]);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPrices();
    // Refresh every 60 seconds
    const interval = setInterval(fetchPrices, 60000);
    return () => clearInterval(interval);
  }, [fetchPrices]);

  return { assets, loading, error, lastUpdated, refetch: fetchPrices };
}

export function formatPrice(price: number): string {
  if (price >= 1000) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  }
  if (price >= 1) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 4,
    }).format(price);
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 4,
    maximumFractionDigits: 6,
  }).format(price);
}

export function formatLargeNumber(num: number): string {
  if (num >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
  return `$${num.toFixed(2)}`;
}
