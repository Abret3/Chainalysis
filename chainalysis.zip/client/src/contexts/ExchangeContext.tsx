/**
 * Exchange Context
 * Manages linked crypto exchange accounts and their balances
 */

import { createContext, useContext, useState, useEffect } from "react";

export interface LinkedExchange {
  id: string;
  exchange: "binance" | "kraken" | "coinbase" | "huobi" | "okx" | "bybit" | "kucoin";
  walletAddress: string;
  displayName: string;
  linkedAt: string;
  balances: {
    [key: string]: {
      amount: number;
      usdValue: number;
    };
  };
}

interface ExchangeContextType {
  exchanges: LinkedExchange[];
  addExchange: (
    exchange: LinkedExchange["exchange"],
    walletAddress: string,
    displayName: string
  ) => void;
  removeExchange: (id: string) => void;
  updateExchangeBalance: (
    id: string,
    balances: LinkedExchange["balances"]
  ) => void;
  getExchangesByUser: (username: string) => LinkedExchange[];
}

const ExchangeContext = createContext<ExchangeContextType | undefined>(undefined);

export function ExchangeProvider({ children }: { children: React.ReactNode }) {
  const [exchanges, setExchanges] = useState<LinkedExchange[]>(() => {
    const stored = localStorage.getItem("chainalysis_exchanges");
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    localStorage.setItem("chainalysis_exchanges", JSON.stringify(exchanges));
  }, [exchanges]);

  const addExchange = (
    exchange: LinkedExchange["exchange"],
    walletAddress: string,
    displayName: string
  ) => {
    const newExchange: LinkedExchange = {
      id: `${exchange}_${Date.now()}`,
      exchange,
      walletAddress,
      displayName,
      linkedAt: new Date().toISOString(),
      balances: {},
    };
    setExchanges((prev) => [...prev, newExchange]);
  };

  const removeExchange = (id: string) => {
    setExchanges((prev) => prev.filter((e) => e.id !== id));
  };

  const updateExchangeBalance = (
    id: string,
    balances: LinkedExchange["balances"]
  ) => {
    setExchanges((prev) =>
      prev.map((e) => (e.id === id ? { ...e, balances } : e))
    );
  };

  const getExchangesByUser = (username: string) => {
    // In a real app, this would filter by user
    // For now, return all exchanges
    return exchanges;
  };

  return (
    <ExchangeContext.Provider
      value={{
        exchanges,
        addExchange,
        removeExchange,
        updateExchangeBalance,
        getExchangesByUser,
      }}
    >
      {children}
    </ExchangeContext.Provider>
  );
}

export function useExchanges() {
  const context = useContext(ExchangeContext);
  if (!context) {
    throw new Error("useExchanges must be used within ExchangeProvider");
  }
  return context;
}
