import React, { createContext, useContext, useState, useEffect } from "react";
import { useUsers } from "./UserContext";

interface User {
  username: string;
  displayName: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = sessionStorage.getItem("chainalysis_user");
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // Get users from UserContext
  const { getUserByUsername } = useUsers();

  const login = (username: string, password: string): boolean => {
    const lowerUser = username.toLowerCase();
    const userAccount = getUserByUsername(lowerUser);
    
    if (userAccount && userAccount.password === password) {
      const userData: User = { username: lowerUser, displayName: userAccount.displayName };
      setUser(userData);
      sessionStorage.setItem("chainalysis_user", JSON.stringify(userData));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem("chainalysis_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
