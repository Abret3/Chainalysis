import React, { createContext, useContext, useState, useEffect } from "react";

export interface Transaction {
  id: string;
  userId: string; // Link transaction to specific user
  amount: number;
  type: "send" | "receive" | "buy" | "sell" | "swap";
  asset: string;
  date: string; // ISO string
  status: "pending" | "completed" | "failed";
  description: string;
}

interface TransactionContextType {
  transactions: Transaction[];
  addTransaction: (tx: Omit<Transaction, "id">) => void;
  updateTransaction: (id: string, tx: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  clearAllTransactions: () => void;
  getTransactionsByUser: (userId: string) => Transaction[];
  deleteUserTransactions: (userId: string) => void;
}

const TransactionContext = createContext<TransactionContextType | null>(null);

export function TransactionProvider({ children }: { children: React.ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const stored = localStorage.getItem("chainalysis_transactions");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Persist to localStorage whenever transactions change
  useEffect(() => {
    localStorage.setItem("chainalysis_transactions", JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (tx: Omit<Transaction, "id">) => {
    const newTx: Transaction = {
      ...tx,
      id: `${tx.userId}-${Date.now()}`,
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const getTransactionsByUser = (userId: string) => {
    return transactions.filter((tx) => tx.userId === userId);
  };

  const deleteUserTransactions = (userId: string) => {
    setTransactions((prev) => prev.filter((tx) => tx.userId !== userId));
  };

  const updateTransaction = (id: string, updates: Partial<Transaction>) => {
    setTransactions((prev) =>
      prev.map((tx) => (tx.id === id ? { ...tx, ...updates } : tx))
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((tx) => tx.id !== id));
  };

  const clearAllTransactions = () => {
    setTransactions([]);
  };

  return (
    <TransactionContext.Provider
      value={{
        transactions,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        clearAllTransactions,
        getTransactionsByUser,
        deleteUserTransactions,
      }}
    >
      {children}
    </TransactionContext.Provider>
  );
}

export function useTransactions() {
  const ctx = useContext(TransactionContext);
  if (!ctx) throw new Error("useTransactions must be used within TransactionProvider");
  return ctx;
}

export function useUserTransactions(userId: string) {
  const { getTransactionsByUser } = useTransactions();
  return getTransactionsByUser(userId);
}
