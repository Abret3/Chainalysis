import React, { createContext, useContext, useState, useEffect } from "react";

export interface UserAccount {
  username: string;
  email: string;
  password: string;
  displayName: string;
  walletBalance: number; // in USD
  createdAt: string;
}

interface UserContextType {
  users: UserAccount[];
  addUser: (user: UserAccount) => void;
  updateUser: (username: string, updates: Partial<UserAccount>) => void;
  deleteUser: (username: string) => void;
  getUserByUsername: (username: string) => UserAccount | undefined;
  getUserByEmail: (email: string) => UserAccount | undefined;
  updateWalletBalance: (username: string, balance: number) => void;
  validateEmail: (email: string) => boolean;
}

const UserContext = createContext<UserContextType | null>(null);

// Email validation regex
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Default users
const DEFAULT_USERS: UserAccount[] = [
  {
    username: "admin",
    email: "admin@chainalysis.com",
    password: "admin123",
    displayName: "Admin",
    walletBalance: 50000,
    createdAt: new Date().toISOString(),
  },
  {
    username: "user",
    email: "user@chainalysis.com",
    password: "password",
    displayName: "User",
    walletBalance: 10000,
    createdAt: new Date().toISOString(),
  },
  {
    username: "demo",
    email: "demo@chainalysis.com",
    password: "demo",
    displayName: "Demo User",
    walletBalance: 5000,
    createdAt: new Date().toISOString(),
  },
];

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useState<UserAccount[]>(() => {
    try {
      const stored = localStorage.getItem("chainalysis_users");
      return stored ? JSON.parse(stored) : DEFAULT_USERS;
    } catch {
      return DEFAULT_USERS;
    }
  });

  // Persist to localStorage whenever users change
  useEffect(() => {
    localStorage.setItem("chainalysis_users", JSON.stringify(users));
  }, [users]);

  const validateEmail = (email: string): boolean => {
    return EMAIL_REGEX.test(email);
  };

  const addUser = (user: UserAccount) => {
    // Check if username already exists
    if (users.some((u) => u.username === user.username)) {
      throw new Error("Username already exists");
    }
    // Check if email already exists
    if (users.some((u) => u.email === user.email)) {
      throw new Error("Email already exists");
    }
    // Validate email format
    if (!validateEmail(user.email)) {
      throw new Error("Invalid email format");
    }
    setUsers((prev) => [...prev, user]);
  };

  const updateUser = (username: string, updates: Partial<UserAccount>) => {
    // If updating email, validate it
    if (updates.email && !validateEmail(updates.email)) {
      throw new Error("Invalid email format");
    }
    // If updating email, check if it's already taken
    if (updates.email) {
      const existingUser = users.find(
        (u) => u.email === updates.email && u.username !== username
      );
      if (existingUser) {
        throw new Error("Email already exists");
      }
    }
    setUsers((prev) =>
      prev.map((u) =>
        u.username === username ? { ...u, ...updates } : u
      )
    );
  };

  const deleteUser = (username: string) => {
    // Prevent deleting admin user
    if (username === "admin") {
      throw new Error("Cannot delete admin user");
    }
    setUsers((prev) => prev.filter((u) => u.username !== username));
  };

  const getUserByUsername = (username: string) => {
    return users.find((u) => u.username === username);
  };

  const getUserByEmail = (email: string) => {
    return users.find((u) => u.email === email);
  };

  const updateWalletBalance = (username: string, balance: number) => {
    updateUser(username, { walletBalance: balance });
  };

  return (
    <UserContext.Provider
      value={{
        users,
        addUser,
        updateUser,
        deleteUser,
        getUserByUsername,
        getUserByEmail,
        updateWalletBalance,
        validateEmail,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUsers() {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error("useUsers must be used within UserProvider");
  return ctx;
}
