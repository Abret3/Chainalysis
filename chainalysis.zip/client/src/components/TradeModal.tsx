/**
 * Trade Modal Component
 * Allows users to buy/sell crypto with payment method selection
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { ArrowRightLeft, Copy, Check } from "lucide-react";
import { QRCodeSVG as QRCode } from "qrcode.react";

interface TradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  asset: {
    symbol: string;
    name: string;
    price: number;
    change24h: number;
  };
  onConfirmTrade: (trade: {
    type: "buy" | "sell";
    amount: number;
    usdAmount: number;
  }) => void;
}

export function TradeModal({
  open,
  onOpenChange,
  asset,
  onConfirmTrade,
}: TradeModalProps) {
  const [step, setStep] = useState<"trade" | "payment" | "confirmation">("trade");
  const [tradeType, setTradeType] = useState<"buy" | "sell">("buy");
  const [amount, setAmount] = useState<number>(0);
  const [amountType, setAmountType] = useState<"crypto" | "usd">("usd");
  const [copied, setCopied] = useState(false);

  const btcWallet = "bc1qatvqtq4dletduhmhhaxyhm4fmmttxkggam2ex7";

  // Calculate amounts
  const cryptoAmount = amountType === "crypto" ? amount : amount / asset.price;
  const usdAmount = amountType === "usd" ? amount : amount * asset.price;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(btcWallet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Wallet address copied!");
  };

  const handleConfirmPayment = () => {
    if (amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    onConfirmTrade({
      type: tradeType,
      amount: cryptoAmount,
      usdAmount: usdAmount,
    });

    // Reset and close
    setStep("trade");
    setAmount(0);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        style={{
          background: "#1a1a24",
          border: "1px solid rgba(255,255,255,0.1)",
        }}
        className="max-w-md"
      >
        {step === "trade" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <span className="text-2xl">{asset.symbol}</span>
                Trade {asset.name}
              </DialogTitle>
              <DialogDescription className="text-slate-400">
                Current price: ${asset.price.toFixed(2)}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              {/* Trade Type Selection */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setTradeType("buy")}
                  className={`p-3 rounded-lg font-semibold transition-all ${
                    tradeType === "buy"
                      ? "bg-green-500/20 border border-green-500 text-green-400"
                      : "bg-white/5 border border-white/10 text-slate-400"
                  }`}
                >
                  Buy
                </button>
                <button
                  onClick={() => setTradeType("sell")}
                  className={`p-3 rounded-lg font-semibold transition-all ${
                    tradeType === "sell"
                      ? "bg-red-500/20 border border-red-500 text-red-400"
                      : "bg-white/5 border border-white/10 text-slate-400"
                  }`}
                >
                  Sell
                </button>
              </div>

              {/* Amount Input */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-300 text-sm">Amount</Label>
                  <button
                    onClick={() =>
                      setAmountType(amountType === "usd" ? "crypto" : "usd")
                    }
                    className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1"
                  >
                    <ArrowRightLeft size={12} />
                    Switch to {amountType === "usd" ? "Crypto" : "USD"}
                  </button>
                </div>

                <div className="relative">
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    className="bg-white/5 border-white/10 text-white pr-12"
                    step="0.01"
                    min="0"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 text-sm">
                    {amountType === "usd" ? "USD" : asset.symbol}
                  </span>
                </div>

                {amount > 0 && (
                  <div className="bg-white/5 rounded-lg p-3 text-sm">
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>
                        {amountType === "usd" ? "Crypto Amount:" : "USD Amount:"}
                      </span>
                      <span className="text-white font-semibold">
                        {amountType === "usd"
                          ? `${cryptoAmount.toFixed(6)} ${asset.symbol}`
                          : `$${usdAmount.toFixed(2)}`}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400 text-xs">
                      <span>Fee (1%):</span>
                      <span>${(usdAmount * 0.01).toFixed(2)}</span>
                    </div>
                    <div className="border-t border-white/10 mt-2 pt-2 flex justify-between text-slate-300">
                      <span>Total:</span>
                      <span className="text-white font-semibold">
                        ${(usdAmount + usdAmount * 0.01).toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={() => setStep("payment")}
                  disabled={amount <= 0}
                  className="flex-1"
                  style={{ background: tradeType === "buy" ? "#22c55e" : "#ef4444" }}
                >
                  Continue to Payment
                </Button>
                <Button
                  onClick={() => onOpenChange(false)}
                  variant="outline"
                  className="flex-1"
                  style={{
                    borderColor: "rgba(255,255,255,0.1)",
                    color: "#94a3b8",
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </>
        )}

        {step === "payment" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-white">Confirm Payment</DialogTitle>
              <DialogDescription className="text-slate-400">
                Send Bitcoin to complete your {tradeType}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              {/* Order Summary */}
              <div
                className="rounded-lg p-4"
                style={{
                  background: "rgba(37, 99, 235, 0.1)",
                  border: "1px solid rgba(59, 130, 246, 0.2)",
                }}
              >
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-slate-300">
                    <span>Type:</span>
                    <span className="text-white font-semibold capitalize">
                      {tradeType}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Amount:</span>
                    <span className="text-white font-semibold">
                      {cryptoAmount.toFixed(6)} {asset.symbol}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Price:</span>
                    <span className="text-white font-semibold">
                      ${asset.price.toFixed(2)}
                    </span>
                  </div>
                  <div className="border-t border-white/10 pt-2 flex justify-between text-slate-300">
                    <span>Total:</span>
                    <span className="text-white font-semibold">
                      ${(usdAmount + usdAmount * 0.01).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bitcoin Wallet QR Code */}
              <div className="flex flex-col items-center gap-4">
                <div className="bg-white p-3 rounded-lg">
                  <QRCode
                    value={`bitcoin:${btcWallet}?amount=${(usdAmount / 50000).toFixed(8)}`}
                    size={150}
                    level="H"
                    includeMargin={true}
                  />
                </div>
                <p className="text-xs text-slate-400 text-center">
                  Scan QR code or copy wallet address below
                </p>
              </div>

              {/* Wallet Address */}
              <div className="space-y-2">
                <Label className="text-slate-300 text-sm">Bitcoin Wallet Address</Label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={btcWallet}
                    readOnly
                    className="flex-1 bg-white/5 border border-white/10 rounded px-3 py-2 text-xs text-slate-300 font-mono"
                  />
                  <button
                    onClick={handleCopyAddress}
                    className="p-2 hover:bg-white/10 rounded transition-colors"
                  >
                    {copied ? (
                      <Check size={16} className="text-green-400" />
                    ) : (
                      <Copy size={16} className="text-slate-400" />
                    )}
                  </button>
                </div>
              </div>

              {/* Payment Instructions */}
              <div
                className="rounded-lg p-3 text-xs space-y-1"
                style={{
                  background: "rgba(249, 115, 22, 0.05)",
                  border: "1px solid rgba(249, 115, 22, 0.2)",
                }}
              >
                <p className="text-orange-400 font-semibold">Payment Instructions:</p>
                <ol className="list-decimal list-inside text-slate-400 space-y-1">
                  <li>Send exactly ${(usdAmount + usdAmount * 0.01).toFixed(2)} worth of BTC</li>
                  <li>Use the wallet address or scan the QR code</li>
                  <li>Wait for blockchain confirmation (usually 10-30 minutes)</li>
                  <li>Your crypto will be added once payment is confirmed</li>
                </ol>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={handleConfirmPayment}
                  className="flex-1"
                  style={{ background: "#2563eb" }}
                >
                  I've Sent the Payment
                </Button>
                <Button
                  onClick={() => setStep("trade")}
                  variant="outline"
                  className="flex-1"
                  style={{
                    borderColor: "rgba(255,255,255,0.1)",
                    color: "#94a3b8",
                  }}
                >
                  Back
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
