/**
 * Action Modals for Dashboard
 * Withdraw, Send, Receive, Exchange
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCryptoPrices } from "@/hooks/useCryptoPrices";
import { toast } from "sonner";
import { Copy, Check, X } from "lucide-react";

interface ActionModalsProps {
  open: boolean;
  action: "withdraw" | "send" | "receive" | "exchange" | null;
  onClose: () => void;
}

export function ActionModals({ open, action, onClose }: ActionModalsProps) {
  const { assets } = useCryptoPrices();
  const [fromAsset, setFromAsset] = useState("bitcoin");
  const [toAsset, setToAsset] = useState("ethereum");
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState("");
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (action === "withdraw" || action === "send") {
      if (!amount || !address) {
        toast.error("Please fill all fields");
        return;
      }
      toast.success(`${action === "withdraw" ? "Withdrawal" : "Transfer"} initiated successfully`);
    } else if (action === "exchange") {
      if (!amount) {
        toast.error("Please enter amount");
        return;
      }
      toast.success("Swap order placed successfully");
    }
    setAmount("");
    setAddress("");
    onClose();
  };

  // Withdraw Modal
  if (action === "withdraw") {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Withdraw Crypto</DialogTitle>
            <DialogDescription className="text-slate-400">
              Transfer crypto to an external wallet
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-slate-300 text-sm">Select Asset</Label>
              <Select value={fromAsset} onValueChange={setFromAsset}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  {assets.map((a) => (
                    <SelectItem key={a.id} value={a.id} className="text-white">
                      {a.name} ({a.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-300 text-sm">Amount</Label>
              <Input
                type="number"
                step="0.00000001"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00000000"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div>
              <Label className="text-slate-300 text-sm">Recipient Address</Label>
              <Input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="0x742d35Cc6634C0532925a3b844Bc9e7595f..."
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="flex gap-2">
              <Button
                type="submit"
                className="flex-1"
                style={{ background: "#2563eb" }}
              >
                Withdraw
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                style={{
                  borderColor: "rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    );
  }

  // Send Modal
  if (action === "send") {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Send Crypto</DialogTitle>
            <DialogDescription className="text-slate-400">
              Send crypto to another user
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-slate-300 text-sm">Select Asset</Label>
              <Select value={fromAsset} onValueChange={setFromAsset}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  {assets.map((a) => (
                    <SelectItem key={a.id} value={a.id} className="text-white">
                      {a.name} ({a.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-300 text-sm">Amount</Label>
              <Input
                type="number"
                step="0.00000001"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00000000"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div>
              <Label className="text-slate-300 text-sm">Recipient Address</Label>
              <Input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="user@chainalysis.com or wallet address"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="flex gap-2">
              <Button
                type="submit"
                className="flex-1"
                style={{ background: "#ef4444" }}
              >
                Send
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                style={{
                  borderColor: "rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    );
  }

  // Receive Modal
  if (action === "receive") {
    const walletAddress = "1A1z7agoat4oPLSGQstDHzc1yP2moS4ubX";
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Receive Crypto</DialogTitle>
            <DialogDescription className="text-slate-400">
              Share your wallet address to receive funds
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label className="text-slate-300 text-sm">Select Asset</Label>
              <Select value={fromAsset} onValueChange={setFromAsset}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  {assets.map((a) => (
                    <SelectItem key={a.id} value={a.id} className="text-white">
                      {a.name} ({a.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* QR Code placeholder */}
            <div className="flex justify-center p-6 bg-white rounded-lg">
              <div className="w-32 h-32 bg-slate-200 flex items-center justify-center text-slate-600 text-sm">
                QR Code
              </div>
            </div>

            {/* Wallet Address */}
            <div>
              <Label className="text-slate-300 text-sm mb-2 block">Your Wallet Address</Label>
              <div className="flex gap-2">
                <Input
                  type="text"
                  value={walletAddress}
                  readOnly
                  className="bg-white/5 border-white/10 text-white"
                />
                <Button
                  onClick={() => handleCopy(walletAddress)}
                  className="px-3"
                  style={{ background: "#2563eb" }}
                >
                  {copied ? <Check size={16} /> : <Copy size={16} />}
                </Button>
              </div>
            </div>

            <Button
              onClick={onClose}
              className="w-full"
              style={{ background: "#22c55e" }}
            >
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Exchange Modal
  if (action === "exchange") {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Exchange Crypto</DialogTitle>
            <DialogDescription className="text-slate-400">
              Swap one cryptocurrency for another
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-slate-300 text-sm">From</Label>
              <Select value={fromAsset} onValueChange={setFromAsset}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  {assets.map((a) => (
                    <SelectItem key={a.id} value={a.id} className="text-white">
                      {a.name} ({a.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-300 text-sm">Amount</Label>
              <Input
                type="number"
                step="0.00000001"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00000000"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div>
              <Label className="text-slate-300 text-sm">To</Label>
              <Select value={toAsset} onValueChange={setToAsset}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  {assets.map((a) => (
                    <SelectItem key={a.id} value={a.id} className="text-white">
                      {a.name} ({a.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button
                type="submit"
                className="flex-1"
                style={{ background: "#a855f7" }}
              >
                Exchange
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                style={{
                  borderColor: "rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    );
  }

  return null;
}
