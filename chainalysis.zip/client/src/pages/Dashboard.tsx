/**
 * Chainalysis — Dashboard Page
 * Design: "Midnight Ledger" — dark fintech, Bloomberg-meets-SaaS
 * Layout: Fixed 220px left sidebar + main content area
 * Features: Live crypto prices via CoinGecko, wallet overview, asset list
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useCryptoPrices, formatPrice, formatLargeNumber } from "@/hooks/useCryptoPrices";
import { useUserTransactions } from "@/contexts/TransactionContext";
import { ActionModals } from "@/components/ActionModals";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Coins,
  CreditCard,
  ShoppingCart,
  Settings,
  LogOut,
  Bell,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Wallet,
  TrendingUp,
  TrendingDown,
  ChevronRight,
  Layers,
  BarChart2,
  Clock,
  AlertCircle,
  X,
} from "lucide-react";

// ─── Sidebar Nav Items ────────────────────────────────────────────────────────
const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { id: "crypto-assets", label: "Crypto Assets", icon: Coins, path: "/crypto-assets" },
  { id: "payment-methods", label: "Payment Methods", icon: CreditCard, path: "/payment-methods" },
  { id: "buy-crypto", label: "Buy Crypto", icon: ShoppingCart, path: "/buy-crypto" },
  { id: "analytics", label: "Analytics", icon: BarChart2, path: "/analytics" },
  { id: "settings", label: "Settings", icon: Settings, path: "/settings" },
];

const ADMIN_NAV_ITEMS = [
  { id: "admin", label: "Admin Panel", icon: BarChart2, path: "/admin" },
];

// ─── Crypto Icon Component ────────────────────────────────────────────────────
function CryptoIcon({ symbol, color, bgColor }: { symbol: string; color: string; bgColor: string }) {
  const icons: Record<string, React.ReactNode> = {
    BTC: (
      <svg viewBox="0 0 32 32" width="18" height="18" fill="white">
        <path d="M16 0C7.163 0 0 7.163 0 16s7.163 16 16 16 16-7.163 16-16S24.837 0 16 0zm3.89 17.4c.36 1.8-.9 2.7-2.4 3l.34 1.36-1.04.26-.33-1.33c-.27.07-.55.13-.83.19l.33 1.34-1.04.26-.34-1.36c-.22.05-.44.1-.65.14l-1.44.36-.28-1.1s.77-.18.75-.19c.42-.1.5-.4.48-.62l-.48-1.92-.06.01-.67-2.7c-.05-.13-.18-.32-.47-.25.01-.01-.75.19-.75.19l-.29-1.17 1.36-.34c.25-.06.5-.13.74-.19l-.34-1.37 1.04-.26.34 1.36c.28-.07.56-.14.83-.21l-.34-1.35 1.04-.26.34 1.36c1.38-.26 2.42-.16 2.86.91.35.85.17 1.68-.44 2.2.72.17 1.26.65 1.41 1.54zm-2.64-3.14c-.25-1-.97-.73-1.97-.5l.5 2c1 .25 1.72.5 1.47-.5zm.62 3.14c-.28-1.1-1.12-.82-2.25-.56l.55 2.2c1.13-.28 1.98-.54 1.7-1.64z" />
      </svg>
    ),
    ETH: (
      <svg viewBox="0 0 32 32" width="18" height="18" fill="white">
        <path d="M16 0L6 16.5l10 5.9 10-5.9L16 0zM6 18.5l10 13.5 10-13.5-10 5.9-10-5.9z" />
      </svg>
    ),
    SOL: (
      <svg viewBox="0 0 32 32" width="18" height="18" fill="white">
        <path d="M5.5 22.5h21l-3 3h-21l3-3zm0-8h21l-3 3h-21l3-3zm3-8h21l-3 3h-21l3-3z" />
      </svg>
    ),
    USDT: (
      <svg viewBox="0 0 32 32" width="18" height="18" fill="white">
        <path d="M16 0C7.163 0 0 7.163 0 16s7.163 16 16 16 16-7.163 16-16S24.837 0 16 0zm.5 24.5v-5.5c3.9-.2 6.8-1 6.8-2s-2.9-1.8-6.8-2v-3.5h5.5v-2.5h-13v2.5h5.5v3.5c-3.9.2-6.8 1-6.8 2s2.9 1.8 6.8 2v5.5h2z" />
      </svg>
    ),
    BNB: (
      <svg viewBox="0 0 32 32" width="18" height="18" fill="white">
        <path d="M16 4l3.5 3.5-7.5 7.5-3.5-3.5L16 4zm-8 8l3.5 3.5-3.5 3.5L4 16l4-4zm16 0l4 4-3.5 3.5L21 16l3-4zm-8 8l7.5-7.5 3.5 3.5L16 28l-12.5-12.5 3.5-3.5L16 20z" />
      </svg>
    ),
    XRP: (
      <svg viewBox="0 0 32 32" width="18" height="18" fill="white">
        <path d="M5 5h4l7 7 7-7h4l-9 9 9 9h-4l-7-7-7 7H5l9-9-9-9z" />
      </svg>
    ),
  };

  return (
    <div
      className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
      style={{ background: bgColor }}
    >
      {icons[symbol] || (
        <span className="text-white font-bold text-sm">{symbol.charAt(0)}</span>
      )}
    </div>
  );
}

// ─── Sidebar Component ────────────────────────────────────────────────────────
function Sidebar({
  activeNav,
  onNavClick,
  onLogout,
  user,
  isAdmin,
}: {
  activeNav: string;
  onNavClick: (id: string) => void;
  onLogout: () => void;
  user: { username: string; displayName: string } | null;
  isAdmin: boolean;
}) {
  return (
    <aside
      className="fixed left-0 top-0 h-full w-[220px] flex flex-col z-20"
      style={{
        background: "#111118",
        borderRight: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-white/5">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: "linear-gradient(135deg, #1d4ed8, #3b82f6)" }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path
              d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <span
          className="text-[15px] font-bold text-white tracking-tight"
          style={{ fontFamily: "'Space Grotesk', sans-serif" }}
        >
          Chainalysis
        </span>
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 px-3 space-y-0.5 overflow-y-auto">
        {[...NAV_ITEMS, ...(isAdmin ? ADMIN_NAV_ITEMS : [])].map((item) => {
          const isActive = activeNav === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onNavClick(item.id)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150"
              style={{
                background: isActive ? "#2563eb" : "transparent",
                color: isActive ? "white" : "rgba(255,255,255,0.55)",
              }}
              onMouseEnter={(e) => {
                if (!isActive) {
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "rgba(255,255,255,0.06)";
                  (e.currentTarget as HTMLButtonElement).style.color =
                    "rgba(255,255,255,0.85)";
                }
              }}
              onMouseLeave={(e) => {
                if (!isActive) {
                  (e.currentTarget as HTMLButtonElement).style.background = "transparent";
                  (e.currentTarget as HTMLButtonElement).style.color =
                    "rgba(255,255,255,0.55)";
                }
              }}
            >
              <Icon size={16} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* User + Logout */}
      <div className="p-3 border-t border-white/5">
        <div className="flex items-center gap-2.5 px-3 py-2 mb-1">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
            style={{ background: "linear-gradient(135deg, #1d4ed8, #3b82f6)" }}
          >
            {user?.displayName?.charAt(0).toUpperCase() || "U"}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-white truncate">{user?.displayName}</p>
            <p className="text-[10px] text-slate-500 truncate">@{user?.username}</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut size={15} />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}

// ─── Main Dashboard Component ─────────────────────────────────────────────────
export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [activeNav, setActiveNav] = useState("dashboard");
  const { assets, loading, error, lastUpdated, refetch } = useCryptoPrices();
  const userTransactions = useUserTransactions(user?.username || "");
  const [showChat, setShowChat] = useState(true);

  const handleNavClick = (id: string) => {
    if (id === "dashboard") {
      setActiveNav(id);
    } else if (id === "admin") {
      navigate("/admin");
    } else if (id === "crypto-assets") {
      navigate("/crypto-assets");
    } else if (id === "payment-methods") {
      navigate("/payment-methods");
    } else if (id === "buy-crypto") {
      navigate("/buy-crypto");
    } else if (id === "analytics") {
      navigate("/analytics");
    } else if (id === "settings") {
      navigate("/settings");
    }
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const [actionModal, setActionModal] = useState<"withdraw" | "send" | "receive" | "exchange" | null>(null);

  const handleAction = (action: string) => {
    const actionMap: Record<string, "withdraw" | "send" | "receive" | "exchange"> = {
      "Withdraw": "withdraw",
      "Send": "send",
      "Receive": "receive",
      "Exchange": "exchange",
    };
    const modal = actionMap[action];
    if (modal) {
      setActionModal(modal);
    } else {
      toast.info(`${action} feature coming soon`, {
        description: "This functionality will be available in the next update.",
      });
    }
  };

  // Top 4 assets for "Your Assets" panel
  const topAssets = assets.slice(0, 6);

  return (
    <div className="min-h-screen flex" style={{ background: "#0d0d14" }}>
      <Sidebar
        activeNav={activeNav}
        onNavClick={handleNavClick}
        onLogout={handleLogout}
        user={user}
        isAdmin={user?.username === "admin"}
      />

      {/* Main content */}
      <main className="flex-1 ml-[220px] flex flex-col min-h-screen overflow-auto">
        {/* Top bar */}
        <header
          className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
          style={{
            background: "rgba(13,13,20,0.95)",
            backdropFilter: "blur(10px)",
            borderBottom: "1px solid rgba(255,255,255,0.05)",
          }}
        >
          <div>
            <h1
              className="text-xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Dashboard
            </h1>
            <p className="text-sm text-slate-400">
              Welcome back, <span className="text-white font-medium">{user?.displayName}</span>. Here's your wallet overview.
            </p>
          </div>
          <div className="flex items-center gap-3">
            {lastUpdated && (
              <span className="text-xs text-slate-500 hidden md:block">
                Updated {lastUpdated.toLocaleTimeString()}
              </span>
            )}
            <button
              onClick={() => {
                refetch();
                window.location.reload();
              }}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/8 transition-colors"
              title="Refresh all data"
            >
              <RefreshCw size={15} />
            </button>
            <button className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/8 transition-colors relative">
              <Bell size={16} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-blue-500 rounded-full" />
            </button>
          </div>
        </header>

        <div className="flex-1 p-8 space-y-6">
          {/* Error banner */}
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm">
              <AlertCircle size={15} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Top row: Balance card + Payment methods */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
            {/* Total Wallet Balance */}
            <div
              className="lg:col-span-3 rounded-xl p-7 relative overflow-hidden"
              style={{
                background: "linear-gradient(135deg, #1d4ed8 0%, #2563eb 50%, #3b82f6 100%)",
                boxShadow: "0 8px 32px rgba(37,99,235,0.3)",
              }}
            >
              {/* Decorative circles */}
              <div
                className="absolute -top-10 -right-10 w-48 h-48 rounded-full opacity-10"
                style={{ background: "white" }}
              />
              <div
                className="absolute -bottom-16 -right-4 w-36 h-36 rounded-full opacity-10"
                style={{ background: "white" }}
              />
              <p className="text-blue-100 text-sm font-medium mb-3">Total Wallet Balance</p>
              <p
                className="text-4xl font-bold text-white mb-4"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                $0.00
              </p>
              <div className="flex items-center gap-2">
                <span className="text-blue-200 text-xs">0 assets · 0 transactions</span>
              </div>
            </div>

            {/* Payment methods */}
            <div
              className="lg:col-span-2 rounded-xl p-6 flex flex-col items-center justify-center gap-4"
              style={{
                background: "#1a1a24",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div className="text-center">
                <CreditCard className="mx-auto mb-2 text-slate-500" size={28} />
                <p className="text-slate-400 text-sm">No payment methods added.</p>
              </div>
              <button
                onClick={() => handleAction("Add Payment Method")}
                className="px-5 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90"
                style={{ background: "#2563eb" }}
              >
                Add Payment Method
              </button>
            </div>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Withdraw", icon: <Wallet size={18} />, color: "#3b82f6" },
              { label: "Send", icon: <ArrowUpRight size={18} />, color: "#ef4444" },
              { label: "Receive", icon: <ArrowDownLeft size={18} />, color: "#22c55e" },
              { label: "Exchange", icon: <RefreshCw size={18} />, color: "#a855f7" },
            ].map((action) => (
              <button
                key={action.label}
                onClick={() => handleAction(action.label)}
                className="flex items-center justify-center gap-2.5 py-3.5 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-80 active:scale-95"
                style={{
                  background: "#1a1a24",
                  border: "1px solid rgba(255,255,255,0.07)",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor =
                    action.color + "40";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor =
                    "rgba(255,255,255,0.07)";
                }}
              >
                <span style={{ color: action.color }}>{action.icon}</span>
                {action.label}
              </button>
            ))}
          </div>

          {/* Bottom row: Your Assets + Transaction History */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
            {/* Your Assets */}
            <div
              className="lg:col-span-3 rounded-xl overflow-hidden"
              style={{
                background: "#1a1a24",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
                <h2
                  className="text-base font-semibold text-white"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Your Assets
                </h2>
                <button
                  onClick={() => handleAction("View all assets")}
                  className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-colors"
                >
                  View all <ChevronRight size={12} />
                </button>
              </div>

              {loading ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="flex items-center gap-3 animate-pulse">
                      <div className="w-9 h-9 rounded-full bg-white/5" />
                      <div className="flex-1 space-y-1.5">
                        <div className="h-3.5 bg-white/5 rounded w-24" />
                        <div className="h-2.5 bg-white/5 rounded w-16" />
                      </div>
                      <div className="space-y-1.5 text-right">
                        <div className="h-3.5 bg-white/5 rounded w-16" />
                        <div className="h-2.5 bg-white/5 rounded w-20" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="divide-y divide-white/[0.04]">
                  {topAssets.map((asset) => (
                    <div
                      key={asset.id}
                      className="flex items-center gap-3 px-6 py-3.5 hover:bg-white/[0.02] transition-colors cursor-pointer"
                      onClick={() => handleAction(`Trade ${asset.name}`)}
                    >
                      <CryptoIcon
                        symbol={asset.symbol}
                        color={asset.color}
                        bgColor={asset.bgColor}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-white">{asset.name}</p>
                        <p className="text-xs text-slate-500">
                          0.0000 {asset.symbol}
                        </p>
                      </div>
                      <div className="text-right">
                        <p
                          className="text-sm font-semibold text-white"
                          style={{ fontFamily: "'JetBrains Mono', monospace" }}
                        >
                          $0.00
                        </p>
                        <p
                          className="text-xs text-slate-500"
                          style={{ fontFamily: "'JetBrains Mono', monospace" }}
                        >
                          @{formatPrice(asset.price)}
                        </p>
                      </div>
                      <div className="ml-3 text-right hidden sm:block">
                        <div
                          className="flex items-center gap-0.5 text-xs font-medium"
                          style={{
                            color: asset.change24h >= 0 ? "#22c55e" : "#ef4444",
                          }}
                        >
                          {asset.change24h >= 0 ? (
                            <TrendingUp size={12} />
                          ) : (
                            <TrendingDown size={12} />
                          )}
                          {Math.abs(asset.change24h).toFixed(2)}%
                        </div>
                        <p className="text-[10px] text-slate-600">24h</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Transaction History */}
            <div
              className="lg:col-span-2 rounded-xl overflow-hidden"
              style={{
                background: "#1a1a24",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
                <h2
                  className="text-base font-semibold text-white"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Transaction History
                </h2>
                <Clock size={15} className="text-slate-500" />
              </div>
              {userTransactions.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-slate-500">
                  <Layers size={28} className="mb-2 opacity-40" />
                  <p className="text-sm">No transactions yet</p>
                </div>
              ) : (
                <div className="divide-y divide-white/[0.04] max-h-96 overflow-y-auto">
                  {userTransactions.slice(0, 8).map((tx) => {
                    const typeColors: Record<string, string> = {
                      send: "#ef4444",
                      receive: "#22c55e",
                      buy: "#3b82f6",
                      sell: "#f59e0b",
                      swap: "#a855f7",
                    };
                    const statusColors: Record<string, string> = {
                      pending: "#f59e0b",
                      completed: "#22c55e",
                      failed: "#ef4444",
                    };
                    return (
                      <div key={tx.id} className="px-6 py-3 hover:bg-white/[0.02] transition-colors">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span
                              className="px-2 py-0.5 rounded text-xs font-semibold text-white"
                              style={{
                                background: typeColors[tx.type] + "20",
                                color: typeColors[tx.type],
                              }}
                            >
                              {tx.type.toUpperCase()}
                            </span>
                            <span className="text-xs text-slate-500">{tx.asset}</span>
                          </div>
                          <span
                            className="text-xs font-mono text-white"
                            style={{ fontFamily: "'JetBrains Mono', monospace" }}
                          >
                            {tx.amount.toFixed(4)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-slate-500">{tx.description}</p>
                          <span
                            className="text-xs font-medium"
                            style={{ color: statusColors[tx.status] }}
                          >
                            {tx.status}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Market Overview — Live Prices */}
          <div
            className="rounded-xl overflow-hidden"
            style={{
              background: "#1a1a24",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
              <h2
                className="text-base font-semibold text-white"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                Market Overview
              </h2>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs text-slate-400">Live</span>
              </div>
            </div>

            {loading ? (
              <div className="p-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="animate-pulse space-y-2 p-4 rounded-lg bg-white/3">
                    <div className="h-4 bg-white/5 rounded w-20" />
                    <div className="h-6 bg-white/5 rounded w-28" />
                    <div className="h-3 bg-white/5 rounded w-16" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-5 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {assets.map((asset) => (
                  <div
                    key={asset.id}
                    className="p-4 rounded-xl transition-all hover:bg-white/[0.03] cursor-pointer"
                    style={{ border: "1px solid rgba(255,255,255,0.04)" }}
                    onClick={() => handleAction(`Trade ${asset.name}`)}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <CryptoIcon
                        symbol={asset.symbol}
                        color={asset.color}
                        bgColor={asset.bgColor}
                      />
                      <div>
                        <p className="text-xs font-bold text-white">{asset.symbol}</p>
                        <p className="text-[10px] text-slate-500">{asset.name}</p>
                      </div>
                    </div>
                    <p
                      className="text-sm font-bold text-white mb-1"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}
                    >
                      {formatPrice(asset.price)}
                    </p>
                    <div className="flex items-center justify-between">
                      <span
                        className="text-xs font-medium flex items-center gap-0.5"
                        style={{
                          color: asset.change24h >= 0 ? "#22c55e" : "#ef4444",
                        }}
                      >
                        {asset.change24h >= 0 ? (
                          <TrendingUp size={11} />
                        ) : (
                          <TrendingDown size={11} />
                        )}
                        {Math.abs(asset.change24h).toFixed(2)}%
                      </span>
                      <span className="text-[10px] text-slate-600">
                        {formatLargeNumber(asset.marketCap)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Live chat widget */}
      {showChat && (
        <div
          className="fixed bottom-6 right-6 z-50 rounded-xl p-4 flex items-center gap-3 shadow-2xl"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
            minWidth: "240px",
            boxShadow: "0 20px 40px rgba(0,0,0,0.5)",
          }}
        >
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
            style={{ background: "linear-gradient(135deg, #1d4ed8, #3b82f6)" }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                stroke="white"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-white">Chainalysis</p>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block" />
              Hi, how can we help?
            </p>
          </div>
          <button
            onClick={() => setShowChat(false)}
            className="text-slate-500 hover:text-white transition-colors"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Action Modals */}
      <ActionModals
        open={actionModal !== null}
        action={actionModal}
        onClose={() => setActionModal(null)}
      />
    </div>
  );
}
