/**
 * Chainalysis — Settings Page
 * Account and security settings
 */

import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import {
  ArrowLeft,
  Lock,
  Bell,
  Eye,
  EyeOff,
  Shield,
  LogOut,
} from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const [, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPasswords, setShowPasswords] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
  });

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error("Please fill all fields");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    toast.success("Password changed successfully");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const handleLogout = () => {
    logout();
    navigate("/");
    toast.success("Logged out successfully");
  };

  return (
    <div className="min-h-screen" style={{ background: "#0d0d14" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          background: "rgba(13,13,20,0.95)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-400" />
          </button>
          <div>
            <h1
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Settings
            </h1>
            <p className="text-sm text-slate-400">Manage your account</p>
          </div>
        </div>
      </header>

      <main className="p-8 max-w-2xl">
        {/* Account Info */}
        <div
          className="p-6 rounded-lg mb-6"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <h2
            className="text-lg font-semibold text-white mb-4"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Account Information
          </h2>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300 text-sm">Username</Label>
              <Input
                type="text"
                value={user?.username || ""}
                disabled
                className="bg-white/5 border-white/10 text-slate-400"
              />
            </div>
            <div>
              <Label className="text-slate-300 text-sm">Display Name</Label>
              <Input
                type="text"
                value={user?.displayName || ""}
                disabled
                className="bg-white/5 border-white/10 text-slate-400"
              />
            </div>
            <div>
              <Label className="text-slate-300 text-sm">Email</Label>
              <Input
                type="email"
                value="user@chainalysis.com"
                disabled
                className="bg-white/5 border-white/10 text-slate-400"
              />
            </div>
          </div>
        </div>

        {/* Change Password */}
        <div
          className="p-6 rounded-lg mb-6"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <h2
            className="text-lg font-semibold text-white mb-4 flex items-center gap-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            <Lock size={18} />
            Change Password
          </h2>
          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <Label className="text-slate-300 text-sm">Current Password</Label>
              <div className="relative">
                <Input
                  type={showPasswords ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                  className="bg-white/5 border-white/10 text-white pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPasswords(!showPasswords)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  {showPasswords ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div>
              <Label className="text-slate-300 text-sm">New Password</Label>
              <Input
                type={showPasswords ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div>
              <Label className="text-slate-300 text-sm">Confirm Password</Label>
              <Input
                type={showPasswords ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              style={{ background: "#2563eb" }}
            >
              Update Password
            </Button>
          </form>
        </div>

        {/* Notifications */}
        <div
          className="p-6 rounded-lg mb-6"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <h2
            className="text-lg font-semibold text-white mb-4 flex items-center gap-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            <Bell size={18} />
            Notifications
          </h2>
          <div className="space-y-4">
            {[
              { key: "email", label: "Email Notifications", desc: "Receive updates via email" },
              { key: "sms", label: "SMS Alerts", desc: "Get alerts via SMS" },
              { key: "push", label: "Push Notifications", desc: "Browser push notifications" },
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between p-3 rounded-lg bg-white/3">
                <div>
                  <p className="text-white font-medium text-sm">{item.label}</p>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
                <input
                  type="checkbox"
                  checked={notifications[item.key as keyof typeof notifications]}
                  onChange={(e) =>
                    setNotifications({
                      ...notifications,
                      [item.key]: e.target.checked,
                    })
                  }
                  className="w-5 h-5 rounded cursor-pointer"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Security */}
        <div
          className="p-6 rounded-lg mb-6"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <h2
            className="text-lg font-semibold text-white mb-4 flex items-center gap-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            <Shield size={18} />
            Security
          </h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-white/3">
              <div>
                <p className="text-white font-medium text-sm">Two-Factor Authentication</p>
                <p className="text-xs text-slate-500">Add extra security to your account</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                style={{
                  borderColor: "rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                Enable
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-white/3">
              <div>
                <p className="text-white font-medium text-sm">Session Timeout</p>
                <p className="text-xs text-slate-500">Auto-logout after 30 minutes</p>
              </div>
              <input type="checkbox" className="w-5 h-5 rounded cursor-pointer" defaultChecked />
            </div>
          </div>
        </div>

        {/* Logout */}
        <div
          className="p-6 rounded-lg border"
          style={{
            background: "#1a1a24",
            borderColor: "rgba(239,68,68,0.2)",
          }}
        >
          <h2
            className="text-lg font-semibold text-red-400 mb-2 flex items-center gap-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            <LogOut size={18} />
            Sign Out
          </h2>
          <p className="text-sm text-slate-400 mb-4">
            You will be logged out from all devices
          </p>
          <Button
            onClick={handleLogout}
            style={{ background: "#ef4444" }}
          >
            Sign Out
          </Button>
        </div>
      </main>
    </div>
  );
}
