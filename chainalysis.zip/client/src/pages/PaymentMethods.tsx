/**
 * Chainalysis — Payment Methods Page
 * Bitcoin wallet and crypto exchange integration
 */

import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useExchanges } from "@/contexts/ExchangeContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useState } from "react";
import {
  ArrowLeft,
  Bitcoin,
  Copy,
  Check,
  Plus,
  Trash2,
  ExternalLink,
} from "lucide-react";
import { toast } from "sonner";

const BITCOIN_WALLET = "bc1qatvqtq4dletduhmhhaxyhm4fmmttxkggam2ex7";

const EXCHANGES = [
  { id: "binance", name: "Binance", icon: "🔶", color: "#F3BA2F" },
  { id: "kraken", name: "Kraken", icon: "🐙", color: "#623582" },
  { id: "coinbase", name: "Coinbase", icon: "💙", color: "#0052FF" },
  { id: "huobi", name: "Huobi", icon: "🌐", color: "#1E1E1E" },
  { id: "okx", name: "OKX", icon: "⚫", color: "#000000" },
  { id: "bybit", name: "Bybit", icon: "📊", color: "#F7931A" },
  { id: "kucoin", name: "KuCoin", icon: "🔷", color: "#26A17B" },
];

export default function PaymentMethods() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { exchanges, addExchange, removeExchange } = useExchanges();
  const [copied, setCopied] = useState(false);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [selectedExchange, setSelectedExchange] = useState<string>(EXCHANGES[0]?.id || "");
  const [walletAddress, setWalletAddress] = useState("");
  const [displayName, setDisplayName] = useState("");

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(BITCOIN_WALLET);
    setCopied(true);
    toast.success("Wallet address copied to clipboard");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLinkExchange = () => {
    if (!selectedExchange || !walletAddress.trim()) {
      toast.error("Please select an exchange and enter a wallet address");
      return;
    }

    const exchangeName =
      EXCHANGES.find((e) => e.id === selectedExchange)?.name || selectedExchange;
    const finalDisplayName = displayName.trim() || `${exchangeName} Wallet`;

    addExchange(
      selectedExchange as any,
      walletAddress.trim(),
      finalDisplayName
    );

    toast.success(`${exchangeName} wallet linked successfully!`);
    setSelectedExchange("");
    setWalletAddress("");
    setDisplayName("");
    setLinkDialogOpen(false);
  };

  const handleRemoveExchange = (id: string) => {
    removeExchange(id);
    toast.success("Exchange wallet removed");
  };

  const getExchangeInfo = (exchangeId: string) => {
    return EXCHANGES.find((e) => e.id === exchangeId);
  };

  return (
    <div className="min-h-screen" style={{ background: "#0d0d14" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          background: "rgba(13,13,20,0.95)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-400" />
          </button>
          <div>
            <h1
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Payment Methods
            </h1>
            <p className="text-sm text-slate-400">Manage your payment methods and linked exchanges</p>
          </div>
        </div>
      </header>

      <main className="p-8 max-w-4xl">
        {/* Bitcoin Wallet Card */}
        <div
          className="rounded-xl p-8 border mb-8"
          style={{
            background: "linear-gradient(135deg, #1a1a24 0%, #2d2d3d 100%)",
            borderColor: "rgba(255,255,255,0.1)",
          }}
        >
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div
                className="p-3 rounded-lg"
                style={{ background: "#f7931a" }}
              >
                <Bitcoin size={24} className="text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-white">Bitcoin Wallet</h2>
                <p className="text-sm text-slate-400">Primary payment method</p>
              </div>
            </div>
            <div
              className="px-3 py-1 rounded-full text-xs font-medium"
              style={{ background: "rgba(34, 197, 94, 0.1)", color: "#22c55e" }}
            >
              Active
            </div>
          </div>

          {/* Wallet Address Display */}
          <div
            className="p-4 rounded-lg mb-6 border"
            style={{
              background: "rgba(0,0,0,0.3)",
              borderColor: "rgba(255,255,255,0.05)",
            }}
          >
            <p className="text-xs text-slate-400 mb-2">Wallet Address</p>
            <div className="flex items-center justify-between gap-3">
              <code
                className="text-sm font-mono text-slate-300 break-all"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                {BITCOIN_WALLET}
              </code>
              <button
                onClick={handleCopyAddress}
                className="flex-shrink-0 p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                {copied ? (
                  <Check size={18} className="text-green-400" />
                ) : (
                  <Copy size={18} className="text-slate-400" />
                )}
              </button>
            </div>
          </div>

          {/* Instructions */}
          <div
            className="p-4 rounded-lg border"
            style={{
              background: "rgba(59, 130, 246, 0.05)",
              borderColor: "rgba(59, 130, 246, 0.2)",
            }}
          >
            <h3 className="text-sm font-semibold text-white mb-3">How to Send Bitcoin</h3>
            <ol className="space-y-2 text-sm text-slate-300">
              <li className="flex gap-3">
                <span className="text-blue-400 font-semibold">1.</span>
                <span>Open your Bitcoin wallet or exchange</span>
              </li>
              <li className="flex gap-3">
                <span className="text-blue-400 font-semibold">2.</span>
                <span>Click "Send" or "Withdraw"</span>
              </li>
              <li className="flex gap-3">
                <span className="text-blue-400 font-semibold">3.</span>
                <span>Paste the wallet address above</span>
              </li>
              <li className="flex gap-3">
                <span className="text-blue-400 font-semibold">4.</span>
                <span>Enter the amount and confirm the transaction</span>
              </li>
              <li className="flex gap-3">
                <span className="text-blue-400 font-semibold">5.</span>
                <span>Your crypto will arrive after blockchain confirmation</span>
              </li>
            </ol>
          </div>
        </div>

        {/* Linked Exchanges Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-white">Linked Exchanges</h2>
              <p className="text-sm text-slate-400">Connect your crypto exchange wallets</p>
            </div>
            <Button
              onClick={() => setLinkDialogOpen(true)}
              className="flex items-center gap-2"
              style={{ background: "#2563eb" }}
            >
              <Plus size={16} />
              Link Exchange
            </Button>
          </div>

          {/* Linked Exchanges Grid */}
          {exchanges.length === 0 ? (
            <div
              className="rounded-lg p-8 text-center border"
              style={{
                background: "rgba(255,255,255,0.02)",
                borderColor: "rgba(255,255,255,0.05)",
              }}
            >
              <p className="text-slate-400 mb-4">No exchanges linked yet</p>
              <p className="text-sm text-slate-500">
                Link your crypto exchange wallets to view balances and manage your assets
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {exchanges.map((exchange) => {
                const exchangeInfo = getExchangeInfo(exchange.exchange);
                return (
                  <div
                    key={exchange.id}
                    className="p-6 rounded-lg border"
                    style={{
                      background: "#1a1a24",
                      borderColor: "rgba(255,255,255,0.06)",
                    }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center text-lg"
                          style={{ background: exchangeInfo?.color + "20" }}
                        >
                          {exchangeInfo?.icon}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-white">
                            {exchange.displayName}
                          </p>
                          <p className="text-xs text-slate-500">
                            {exchangeInfo?.name}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleRemoveExchange(exchange.id)}
                        className="p-2 hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        <Trash2 size={16} className="text-red-400" />
                      </button>
                    </div>

                    {/* Wallet Address */}
                    <div
                      className="p-3 rounded-lg mb-4 border text-xs"
                      style={{
                        background: "rgba(0,0,0,0.2)",
                        borderColor: "rgba(255,255,255,0.05)",
                      }}
                    >
                      <p className="text-slate-400 mb-1">Wallet Address</p>
                      <code
                        className="text-slate-300 break-all font-mono"
                        style={{ fontFamily: "'JetBrains Mono', monospace" }}
                      >
                        {exchange.walletAddress}
                      </code>
                    </div>

                    {/* Linked Date */}
                    <p className="text-xs text-slate-500">
                      Linked {new Date(exchange.linkedAt).toLocaleDateString()}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Info Box */}
        <div
          className="p-4 rounded-lg border"
          style={{
            background: "rgba(251, 146, 60, 0.05)",
            borderColor: "rgba(251, 146, 60, 0.2)",
          }}
        >
          <p className="text-sm text-slate-300">
            <strong className="text-orange-400">Note:</strong> You can link multiple exchange wallets to monitor and manage your assets across different platforms. Bitcoin transfers are processed on the blockchain and may take 10-60 minutes to confirm.
          </p>
        </div>
      </main>

      {/* Link Exchange Dialog */}
      <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
        <DialogContent
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
          className="max-w-md"
        >
          <DialogHeader>
            <DialogTitle className="text-white">Link Crypto Exchange</DialogTitle>
            <DialogDescription className="text-slate-400">
              Connect your exchange wallet to view balances and manage assets
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Exchange Selection */}
            <div className="space-y-2">
              <Label className="text-slate-300">Select Exchange</Label>
              <Select value={selectedExchange || ""} onValueChange={setSelectedExchange}>
                <SelectTrigger
                  className="bg-white/5 border-white/10 text-white"
                  style={{ borderColor: "rgba(255,255,255,0.1)" }}
                >
                  <SelectValue placeholder="Choose an exchange..." />
                </SelectTrigger>
                <SelectContent
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  {EXCHANGES.map((exchange) => (
                    <SelectItem
                      key={exchange.id}
                      value={exchange.id}
                      className="text-white"
                    >
                      <div className="flex items-center gap-2">
                        <span>{exchange.icon}</span>
                        <span>{exchange.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Wallet Address Input */}
            <div className="space-y-2">
              <Label className="text-slate-300">Wallet Address</Label>
              <Input
                type="text"
                placeholder="Enter your wallet address..."
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                className="bg-white/5 border-white/10 text-white placeholder:text-slate-500"
              />
              <p className="text-xs text-slate-500">
                Use your exchange deposit address for this wallet
              </p>
            </div>

            {/* Display Name Input */}
            <div className="space-y-2">
              <Label className="text-slate-300">Display Name (Optional)</Label>
              <Input
                type="text"
                placeholder="e.g., My Trading Account"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="bg-white/5 border-white/10 text-white placeholder:text-slate-500"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button
                onClick={handleLinkExchange}
                className="flex-1"
                style={{ background: "#2563eb" }}
              >
                Link Exchange
              </Button>
              <Button
                onClick={() => setLinkDialogOpen(false)}
                variant="outline"
                className="flex-1"
                style={{
                  borderColor: "rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
