/**
 * Chainalysis — Crypto Assets Page
 * Shows all cryptocurrencies with live prices, market cap, volume, and trade functionality
 */

import { useAuth } from "@/contexts/AuthContext";
import { useUsers } from "@/contexts/UserContext";
import { useTransactions } from "@/contexts/TransactionContext";
import { useLocation } from "wouter";
import { useCryptoPrices, formatPrice, formatLargeNumber } from "@/hooks/useCryptoPrices";
import { TradeModal } from "@/components/TradeModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft,
  Search,
  TrendingUp,
  TrendingDown,
  Star,
  CheckCircle,
} from "lucide-react";

export default function CryptoAssets() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { assets, loading } = useCryptoPrices();
  const { updateWalletBalance, getUserByUsername } = useUsers();
  const { addTransaction } = useTransactions();
  const [searchTerm, setSearchTerm] = useState("");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [tradeOpen, setTradeOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<any>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [lastTrade, setLastTrade] = useState<any>(null);

  const filtered = assets.filter(
    (a) =>
      a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  const handleTradeClick = (asset: any) => {
    setSelectedAsset(asset);
    setTradeOpen(true);
  };

  const handleConfirmTrade = (trade: {
    type: "buy" | "sell";
    amount: number;
    usdAmount: number;
  }) => {
    if (!user) return;

    const userAccount = getUserByUsername(user.username);
    if (!userAccount) {
      toast.error("User not found");
      return;
    }

    // Update wallet balance
    const newBalance =
      trade.type === "buy"
        ? userAccount.walletBalance - (trade.usdAmount + trade.usdAmount * 0.01)
        : userAccount.walletBalance + (trade.usdAmount - trade.usdAmount * 0.01);

    if (newBalance < 0 && trade.type === "buy") {
      toast.error("Insufficient balance");
      return;
    }

    updateWalletBalance(user.username, newBalance);

    // Add transaction
    addTransaction({
      userId: user.username,
      type: trade.type === "buy" ? "buy" : "sell",
      asset: selectedAsset.symbol,
      amount: trade.amount,
      date: new Date().toISOString(),
      status: "pending",
      description: `${trade.type === "buy" ? "Purchased" : "Sold"} ${trade.amount.toFixed(6)} ${selectedAsset.symbol} for $${trade.usdAmount.toFixed(2)}`,
    });

    setLastTrade({
      type: trade.type,
      amount: trade.amount,
      asset: selectedAsset.symbol,
      usdAmount: trade.usdAmount,
      timestamp: new Date(),
    });

    setShowConfirmation(true);

    toast.success(
      `${trade.type === "buy" ? "Purchase" : "Sale"} initiated! Waiting for Bitcoin payment confirmation...`
    );

    // Auto-hide confirmation after 5 seconds
    setTimeout(() => {
      setShowConfirmation(false);
      setTradeOpen(false);
    }, 5000);
  };

  return (
    <div className="min-h-screen" style={{ background: "#0d0d14" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          background: "rgba(13,13,20,0.95)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-400" />
          </button>
          <div>
            <h1
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Crypto Assets
            </h1>
            <p className="text-sm text-slate-400">Browse and trade cryptocurrencies</p>
          </div>
        </div>
      </header>

      <main className="p-8">
        {/* Search */}
        <div className="mb-6 relative">
          <Search
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"
            size={18}
          />
          <Input
            type="text"
            placeholder="Search by name or symbol..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 h-11 bg-white/5 border-white/10 text-white placeholder:text-slate-500"
          />
        </div>

        {/* Confirmation Message */}
        {showConfirmation && lastTrade && (
          <div
            className="mb-6 p-4 rounded-lg border flex items-start gap-3"
            style={{
              background: "rgba(34, 197, 94, 0.05)",
              borderColor: "rgba(34, 197, 94, 0.2)",
            }}
          >
            <CheckCircle className="text-green-400 mt-0.5 flex-shrink-0" size={20} />
            <div>
              <p className="text-white font-semibold mb-1">
                {lastTrade.type === "buy" ? "Purchase" : "Sale"} Initiated!
              </p>
              <p className="text-sm text-slate-300">
                {lastTrade.amount.toFixed(6)} {lastTrade.asset} for ${lastTrade.usdAmount.toFixed(2)}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Status: <span className="text-orange-400">Pending Bitcoin confirmation</span>
              </p>
              <p className="text-xs text-slate-500 mt-2">
                Your transaction will be completed once the Bitcoin payment is confirmed on the blockchain.
              </p>
            </div>
          </div>
        )}

        {/* Assets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loading ? (
            Array(6)
              .fill(0)
              .map((_, i) => (
                <div
                  key={i}
                  className="p-6 rounded-lg animate-pulse"
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <div className="h-6 bg-white/5 rounded w-24 mb-4" />
                  <div className="h-8 bg-white/5 rounded w-32 mb-3" />
                  <div className="h-4 bg-white/5 rounded w-20" />
                </div>
              ))
          ) : filtered.length === 0 ? (
            <div className="col-span-full text-center py-12 text-slate-500">
              <p>No cryptocurrencies found</p>
            </div>
          ) : (
            filtered.map((asset) => (
              <div
                key={asset.id}
                className="p-6 rounded-lg hover:bg-white/[0.03] transition-all group"
                style={{
                  background: "#1a1a24",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ background: asset.bgColor }}
                    >
                      <span className="text-white font-bold text-sm">
                        {asset.symbol.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">
                        {asset.name}
                      </p>
                      <p className="text-xs text-slate-500">{asset.symbol}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleFavorite(asset.id)}
                    className="p-1.5 rounded hover:bg-white/10 transition-colors"
                  >
                    <Star
                      size={16}
                      className={
                        favorites.includes(asset.id)
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-slate-500"
                      }
                    />
                  </button>
                </div>

                <p
                  className="text-lg font-bold text-white mb-2"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {formatPrice(asset.price)}
                </p>

                <div className="space-y-2 mb-4 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>24h Change</span>
                    <span
                      style={{
                        color: asset.change24h >= 0 ? "#22c55e" : "#ef4444",
                      }}
                      className="font-semibold flex items-center gap-1"
                    >
                      {asset.change24h >= 0 ? (
                        <TrendingUp size={12} />
                      ) : (
                        <TrendingDown size={12} />
                      )}
                      {Math.abs(asset.change24h).toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Market Cap</span>
                    <span className="text-white font-mono">
                      {formatLargeNumber(asset.marketCap)}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>24h Volume</span>
                    <span className="text-white font-mono">
                      {formatLargeNumber(asset.volume24h)}
                    </span>
                  </div>
                </div>

                <Button
                  onClick={() => handleTradeClick(asset)}
                  className="w-full h-9 text-sm"
                  style={{ background: "#2563eb" }}
                >
                  Trade {asset.symbol}
                </Button>
              </div>
            ))
          )}
        </div>
      </main>

      {/* Trade Modal */}
      {selectedAsset && (
        <TradeModal
          open={tradeOpen}
          onOpenChange={setTradeOpen}
          asset={selectedAsset}
          onConfirmTrade={handleConfirmTrade}
        />
      )}
    </div>
  );
}
