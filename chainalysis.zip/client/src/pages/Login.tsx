/**
 * Chainalysis — Login Page
 * Design: "Midnight Ledger" — dark fintech, Space Grotesk headings, Inter body
 * Background: blockchain network visualization image
 * Layout: centered card with logo, username/email/password fields
 */

import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useUsers } from "@/contexts/UserContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Lock, User, Mail, AlertCircle } from "lucide-react";

const BG_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663421380194/eYJJdQE5DXMHPYpXTbDnvz/chainalysis-login-bg-mQBRFEqxtHtpnLiYZYAAk9.webp";

export default function Login() {
  const { login } = useAuth();
  const { getUserByUsername, getUserByEmail } = useUsers();
  const [, navigate] = useLocation();
  const [credential, setCredential] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!credential.trim() || !password.trim()) {
      setError("Please enter your username/email and password.");
      return;
    }

    setLoading(true);
    // Simulate a brief auth delay for UX
    await new Promise((r) => setTimeout(r, 600));

    // Try to find user by username or email
    let username: string | undefined;

    // Check if credential is an email
    if (credential.includes("@")) {
      const userByEmail = getUserByEmail(credential.trim());
      if (userByEmail) {
        username = userByEmail.username;
      }
    } else {
      // Try as username
      const userByUsername = getUserByUsername(credential.trim());
      if (userByUsername) {
        username = userByUsername.username;
      }
    }

    if (!username) {
      setLoading(false);
      setError("Invalid username/email or password. Please try again.");
      return;
    }

    const success = login(username, password);
    setLoading(false);
    if (success) {
      navigate("/dashboard");
    } else {
      setError("Invalid username/email or password. Please try again.");
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center relative overflow-hidden"
      style={{
        background: "#0a0a12",
      }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${BG_URL})`,
          opacity: 0.35,
        }}
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a12]/80 via-transparent to-[#0a0a12]/90" />

      {/* Login card */}
      <div className="relative z-10 w-full max-w-[420px] mx-4">
        {/* Logo area */}
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #1d4ed8, #3b82f6)" }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <span
              className="text-2xl font-bold tracking-tight text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Chainalysis
            </span>
          </div>
          <p className="text-sm text-slate-400 text-center">
            Blockchain intelligence & crypto analytics
          </p>
        </div>

        {/* Card */}
        <div
          className="rounded-xl border p-8"
          style={{
            background: "rgba(17, 17, 28, 0.92)",
            backdropFilter: "blur(20px)",
            borderColor: "rgba(255,255,255,0.08)",
            boxShadow: "0 25px 50px rgba(0,0,0,0.6), 0 0 0 1px rgba(37,99,235,0.1)",
          }}
        >
          <div className="mb-6">
            <h1
              className="text-xl font-semibold text-white mb-1"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Sign in to your account
            </h1>
            <p className="text-sm text-slate-400">
              Enter your username or email and password
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Username or Email */}
            <div className="space-y-1.5">
              <Label htmlFor="credential" className="text-sm font-medium text-slate-300">
                Username or Email
              </Label>
              <div className="relative">
                <User
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"
                  size={16}
                />
                <Input
                  id="credential"
                  type="text"
                  placeholder="Enter your username or email"
                  value={credential}
                  onChange={(e) => setCredential(e.target.value)}
                  className="pl-9 h-11 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-blue-500 focus:ring-blue-500/20"
                  autoComplete="username"
                  autoFocus
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm font-medium text-slate-300">
                Password
              </Label>
              <div className="relative">
                <Lock
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"
                  size={16}
                />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-9 pr-10 h-11 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-blue-500 focus:ring-blue-500/20"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Error message */}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                <AlertCircle size={15} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Submit button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 font-semibold text-sm transition-all duration-200"
              style={{
                background: loading
                  ? "rgba(37,99,235,0.5)"
                  : "linear-gradient(135deg, #1d4ed8, #3b82f6)",
                border: "none",
                color: "white",
              }}
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg
                    className="animate-spin h-4 w-4"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                    />
                  </svg>
                  Authenticating...
                </span>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>

          {/* Demo credentials hint */}
          <div
            className="mt-5 p-3 rounded-lg text-xs text-slate-500"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" }}
          >
            <p className="font-medium text-slate-400 mb-2">Demo credentials</p>
            <p className="mb-1">Username: <span className="font-mono text-slate-300">admin</span> &nbsp;|&nbsp; Password: <span className="font-mono text-slate-300">admin123</span></p>
            <p>Email: <span className="font-mono text-slate-300">admin@chainalysis.com</span> &nbsp;|&nbsp; Password: <span className="font-mono text-slate-300">admin123</span></p>
          </div>
        </div>

        <p className="text-center text-xs text-slate-600 mt-6">
          © 2025 Chainalysis Inc. All rights reserved.
        </p>
      </div>
    </div>
  );
}
