/**
 * Chainalysis — Admin Panel
 * Design: "Midnight Ledger" — dark fintech
 * Features: User management, create/edit/delete transactions per user
 */

import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useUsers, UserAccount } from "@/contexts/UserContext";
import { useTransactions, Transaction } from "@/contexts/TransactionContext";
import { useCryptoPrices } from "@/hooks/useCryptoPrices";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Plus,
  Trash2,
  Edit2,
  Calendar,
  DollarSign,
  AlertCircle,
  CheckCircle,
  Clock,
  XCircle,
  Download,
  Trash,
  ArrowLeft,
  Users,
  Layers,
} from "lucide-react";
import { useLocation } from "wouter";

const TRANSACTION_TYPES = [
  { value: "send", label: "Send", color: "#ef4444" },
  { value: "receive", label: "Receive", color: "#22c55e" },
  { value: "buy", label: "Buy", color: "#3b82f6" },
  { value: "sell", label: "Sell", color: "#f59e0b" },
  { value: "swap", label: "Swap", color: "#a855f7" },
];

const TRANSACTION_STATUS = [
  { value: "pending", label: "Pending", icon: Clock, color: "#f59e0b" },
  { value: "completed", label: "Completed", icon: CheckCircle, color: "#22c55e" },
  { value: "failed", label: "Failed", icon: XCircle, color: "#ef4444" },
];

export default function AdminPanel() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { users, addUser, updateUser, deleteUser, getUserByUsername } = useUsers();
  const { transactions, addTransaction, updateTransaction, deleteTransaction, getTransactionsByUser, deleteUserTransactions } =
    useTransactions();
  const { assets } = useCryptoPrices();

  // Transaction management state
  const [selectedUser, setSelectedUser] = useState<string>("admin");
  const [transactionOpen, setTransactionOpen] = useState(false);
  const [editingTxId, setEditingTxId] = useState<string | null>(null);
  const [transactionForm, setTransactionForm] = useState<Omit<Transaction, "id">>({
    userId: "admin",
    amount: 0,
    type: "buy",
    asset: "BTC",
    date: new Date().toISOString().split("T")[0],
    status: "completed",
    description: "",
  });

  // User management state
  const [userOpen, setUserOpen] = useState(false);
  const [editingUsername, setEditingUsername] = useState<string | null>(null);
  const [userForm, setUserForm] = useState<UserAccount>({
    username: "",
    email: "",
    password: "",
    displayName: "",
    walletBalance: 0,
    createdAt: new Date().toISOString(),
  });

  // Redirect if not admin
  if (user?.username !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0d0d14" }}>
        <div className="text-center">
          <AlertCircle className="mx-auto mb-4 text-red-400" size={48} />
          <h1 className="text-xl font-bold text-white mb-2">Access Denied</h1>
          <p className="text-slate-400">Only admin users can access this panel.</p>
        </div>
      </div>
    );
  }

  const userTransactions = getTransactionsByUser(selectedUser);

  // ─── Transaction Handlers ─────────────────────────────────────────────────
  const handleTransactionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (transactionForm.amount <= 0) {
      toast.error("Amount must be greater than 0");
      return;
    }
    if (!transactionForm.description.trim()) {
      toast.error("Please add a description");
      return;
    }

    if (editingTxId) {
      updateTransaction(editingTxId, transactionForm);
      toast.success("Transaction updated");
      setEditingTxId(null);
    } else {
      addTransaction(transactionForm);
      toast.success("Transaction created for " + transactionForm.userId);
    }

    setTransactionForm({
      userId: selectedUser,
      amount: 0,
      type: "buy",
      asset: "BTC",
      date: new Date().toISOString().split("T")[0],
      status: "completed",
      description: "",
    });
    setTransactionOpen(false);
  };

  const handleEditTransaction = (tx: Transaction) => {
    setTransactionForm({
      userId: tx.userId,
      amount: tx.amount,
      type: tx.type,
      asset: tx.asset,
      date: tx.date.split("T")[0],
      status: tx.status,
      description: tx.description,
    });
    setEditingTxId(tx.id);
    setTransactionOpen(true);
  };

  const handleDeleteTransaction = (id: string) => {
    deleteTransaction(id);
    toast.success("Transaction deleted");
  };

  // ─── User Handlers ────────────────────────────────────────────────────────
  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userForm.username.trim()) {
      toast.error("Username is required");
      return;
    }
    if (!userForm.password.trim()) {
      toast.error("Password is required");
      return;
    }
    if (!userForm.displayName.trim()) {
      toast.error("Display name is required");
      return;
    }
    if (userForm.walletBalance < 0) {
      toast.error("Wallet balance cannot be negative");
      return;
    }

    if (editingUsername) {
      updateUser(editingUsername, userForm);
      toast.success("User updated");
      setEditingUsername(null);
    } else {
      // Check if user already exists
      if (getUserByUsername(userForm.username)) {
        toast.error("User already exists");
        return;
      }
      addUser(userForm);
      toast.success("User created");
    }

    setUserForm({
      username: "",
      email: "",
      password: "",
      displayName: "",
      walletBalance: 0,
      createdAt: new Date().toISOString(),
    });
    setUserOpen(false);
  };

  const handleEditUser = (u: UserAccount) => {
    setUserForm(u);
    setEditingUsername(u.username);
    setUserOpen(true);
  };

  const handleDeleteUser = (username: string) => {
    if (username === "admin") {
      toast.error("Cannot delete admin user");
      return;
    }
    if (window.confirm(`Delete user ${username}?`)) {
      deleteUser(username);
      toast.success("User deleted");
    }
  };

  return (
    <div className="min-h-screen" style={{ background: "#0d0d14" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          background: "rgba(13,13,20,0.95)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-400" />
          </button>
          <div>
            <h1
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Admin Panel
            </h1>
            <p className="text-sm text-slate-400">Manage users and transactions</p>
          </div>
        </div>
      </header>

      <main className="p-8 max-w-6xl">
        <Tabs defaultValue="users" className="w-full">
          <TabsList
            className="grid w-full grid-cols-2 mb-8"
            style={{
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.1)",
            }}
          >
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users size={16} />
              User Management
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex items-center gap-2">
              <Layers size={16} />
              Transactions
            </TabsTrigger>
          </TabsList>

          {/* ─── Users Tab ─────────────────────────────────────────────────────── */}
          <TabsContent value="users">
            <div className="space-y-6">
              {/* Add User Button */}
              <div className="flex justify-end">
                <Dialog open={userOpen} onOpenChange={setUserOpen}>
                  <DialogTrigger asChild>
                    <Button
                      className="flex items-center gap-2"
                      style={{ background: "#2563eb" }}
                      onClick={() => {
                        setEditingUsername(null);
                        setUserForm({
                          username: "",
                          email: "",
                          password: "",
                          displayName: "",
                          walletBalance: 0,
                          createdAt: new Date().toISOString(),
                        });
                      }}
                    >
                      <Plus size={16} />
                      Add New User
                    </Button>
                  </DialogTrigger>
                  <DialogContent
                    style={{
                      background: "#1a1a24",
                      border: "1px solid rgba(255,255,255,0.1)",
                    }}
                  >
                    <DialogHeader>
                      <DialogTitle className="text-white">
                        {editingUsername ? "Edit User" : "Create New User"}
                      </DialogTitle>
                      <DialogDescription className="text-slate-400">
                        {editingUsername ? "Update user details" : "Add a new user account"}
                      </DialogDescription>
                    </DialogHeader>

                    <form onSubmit={handleUserSubmit} className="space-y-4">
                      <div>
                        <Label className="text-slate-300 text-sm">Username</Label>
                        <Input
                          type="text"
                          value={userForm.username}
                          onChange={(e) =>
                            setUserForm({ ...userForm, username: e.target.value })
                          }
                          placeholder="e.g., john_trader"
                          className="bg-white/5 border-white/10 text-white"
                          disabled={!!editingUsername}
                        />
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Email</Label>
                        <Input
                          type="email"
                          value={userForm.email}
                          onChange={(e) =>
                            setUserForm({ ...userForm, email: e.target.value })
                          }
                          placeholder="e.g., john@example.com"
                          className="bg-white/5 border-white/10 text-white"
                        />
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Password</Label>
                        <Input
                          type="password"
                          value={userForm.password}
                          onChange={(e) =>
                            setUserForm({ ...userForm, password: e.target.value })
                          }
                          placeholder="Enter password"
                          className="bg-white/5 border-white/10 text-white"
                        />
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Display Name</Label>
                        <Input
                          type="text"
                          value={userForm.displayName}
                          onChange={(e) =>
                            setUserForm({ ...userForm, displayName: e.target.value })
                          }
                          placeholder="e.g., John Trader"
                          className="bg-white/5 border-white/10 text-white"
                        />
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Initial Wallet Balance (USD)</Label>
                        <Input
                          type="number"
                          value={userForm.walletBalance}
                          onChange={(e) =>
                            setUserForm({ ...userForm, walletBalance: parseFloat(e.target.value) || 0 })
                          }
                          placeholder="0.00"
                          className="bg-white/5 border-white/10 text-white"
                          step="0.01"
                          min="0"
                        />
                      </div>

                      <div className="flex gap-2 pt-4">
                        <Button
                          type="submit"
                          className="flex-1"
                          style={{ background: "#2563eb" }}
                        >
                          {editingUsername ? "Update User" : "Create User"}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setUserOpen(false)}
                          style={{
                            borderColor: "rgba(255,255,255,0.1)",
                            color: "#94a3b8",
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Users List */}
              <div
                className="rounded-lg border overflow-hidden"
                style={{
                  background: "#1a1a24",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr
                        style={{
                          borderBottom: "1px solid rgba(255,255,255,0.1)",
                          background: "rgba(0,0,0,0.3)",
                        }}
                      >
                        <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                          Username
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                          Display Name
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-semibold text-slate-300">
                          Wallet Balance
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                          Created
                        </th>
                        <th className="px-6 py-3 text-center text-xs font-semibold text-slate-300">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((u) => (
                        <tr
                          key={u.username}
                          style={{
                            borderBottom: "1px solid rgba(255,255,255,0.05)",
                          }}
                        >
                          <td className="px-6 py-4 text-sm font-mono text-white">
                            {u.username}
                            {u.username === "admin" && (
                              <span className="ml-2 px-2 py-0.5 rounded text-xs bg-blue-500/20 text-blue-400">
                                Admin
                              </span>
                            )}
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-300">
                            {u.displayName}
                          </td>
                          <td className="px-6 py-4 text-sm text-right font-semibold text-white">
                            ${u.walletBalance.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-400">
                            {new Date(u.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="flex justify-center gap-2">
                              <button
                                onClick={() => handleEditUser(u)}
                                className="p-2 hover:bg-white/10 rounded transition-colors"
                              >
                                <Edit2 size={14} className="text-blue-400" />
                              </button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <button className="p-2 hover:bg-white/10 rounded transition-colors">
                                    <DollarSign size={14} className="text-green-400" />
                                  </button>
                                </DialogTrigger>
                                <DialogContent
                                  style={{
                                    background: "#1a1a24",
                                    border: "1px solid rgba(255,255,255,0.1)",
                                  }}
                                >
                                  <DialogHeader>
                                    <DialogTitle className="text-white">Modify Wallet Balance</DialogTitle>
                                    <DialogDescription className="text-slate-400">
                                      Update balance for {u.displayName} ({u.username})
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div>
                                      <Label className="text-slate-300 text-sm mb-2 block">Current Balance</Label>
                                      <div className="text-2xl font-bold text-white">${u.walletBalance.toFixed(2)}</div>
                                    </div>
                                    <div>
                                      <Label className="text-slate-300 text-sm mb-2 block">New Balance (USD)</Label>
                                      <Input
                                        type="number"
                                        defaultValue={u.walletBalance}
                                        id={`balance-${u.username}`}
                                        placeholder="0.00"
                                        className="bg-white/5 border-white/10 text-white"
                                        step="0.01"
                                        min="0"
                                      />
                                    </div>
                                    <div className="flex gap-2 pt-4">
                                      <Button
                                        className="flex-1"
                                        style={{ background: "#22c55e" }}
                                        onClick={() => {
                                          const newBalance = parseFloat(
                                            (document.getElementById(`balance-${u.username}`) as HTMLInputElement)?.value || "0"
                                          );
                                          updateUser(u.username, { ...u, walletBalance: newBalance });
                                          toast.success(`Balance updated to $${newBalance.toFixed(2)}`);
                                        }}
                                      >
                                        Update Balance
                                      </Button>
                                    </div>
                                  </div>
                                </DialogContent>
                              </Dialog>
                              <button
                                onClick={() => handleDeleteUser(u.username)}
                                className="p-2 hover:bg-white/10 rounded transition-colors"
                                disabled={u.username === "admin"}
                              >
                                <Trash2
                                  size={14}
                                  className={u.username === "admin" ? "text-slate-600" : "text-red-400"}
                                />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ─── Transactions Tab ──────────────────────────────────────────────── */}
          <TabsContent value="transactions">
            <div className="space-y-6">
              {/* User Selection */}
              <div>
                <Label className="text-slate-300 text-sm mb-3 block">Select User</Label>
                <Select value={selectedUser} onValueChange={setSelectedUser}>
                  <SelectTrigger
                    className="w-full md:w-64 bg-white/5 border-white/10 text-white"
                    style={{ borderColor: "rgba(255,255,255,0.1)" }}
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent
                    style={{
                      background: "#1a1a24",
                      border: "1px solid rgba(255,255,255,0.1)",
                    }}
                  >
                    {users.map((u) => (
                      <SelectItem key={u.username} value={u.username} className="text-white">
                        {u.displayName} ({u.username})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div
                  className="p-4 rounded-lg border"
                  style={{
                    background: "rgba(59, 130, 246, 0.05)",
                    borderColor: "rgba(59, 130, 246, 0.2)",
                  }}
                >
                  <p className="text-sm text-slate-400 mb-1">Total Transactions</p>
                  <p className="text-2xl font-bold text-white">{userTransactions.length}</p>
                </div>
                <div
                  className="p-4 rounded-lg border"
                  style={{
                    background: "rgba(34, 197, 94, 0.05)",
                    borderColor: "rgba(34, 197, 94, 0.2)",
                  }}
                >
                  <p className="text-sm text-slate-400 mb-1">Completed</p>
                  <p className="text-2xl font-bold text-green-400">
                    {userTransactions.filter((t) => t.status === "completed").length}
                  </p>
                </div>
                <div
                  className="p-4 rounded-lg border"
                  style={{
                    background: "rgba(249, 115, 22, 0.05)",
                    borderColor: "rgba(249, 115, 22, 0.2)",
                  }}
                >
                  <p className="text-sm text-slate-400 mb-1">Pending</p>
                  <p className="text-2xl font-bold text-orange-400">
                    {userTransactions.filter((t) => t.status === "pending").length}
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Dialog open={transactionOpen} onOpenChange={setTransactionOpen}>
                  <DialogTrigger asChild>
                    <Button
                      className="flex items-center gap-2"
                      style={{ background: "#2563eb" }}
                      onClick={() => {
                        setEditingTxId(null);
                        setTransactionForm({
                          userId: selectedUser,
                          amount: 0,
                          type: "buy",
                          asset: "BTC",
                          date: new Date().toISOString().split("T")[0],
                          status: "completed",
                          description: "",
                        });
                      }}
                    >
                      <Plus size={16} />
                      Add Transaction
                    </Button>
                  </DialogTrigger>
                  <DialogContent
                    style={{
                      background: "#1a1a24",
                      border: "1px solid rgba(255,255,255,0.1)",
                    }}
                  >
                    <DialogHeader>
                      <DialogTitle className="text-white">
                        {editingTxId ? "Edit" : "Add"} Transaction for {selectedUser}
                      </DialogTitle>
                      <DialogDescription className="text-slate-400">
                        Create or update a transaction for this user
                      </DialogDescription>
                    </DialogHeader>

                    <form onSubmit={handleTransactionSubmit} className="space-y-4">
                      <div>
                        <Label className="text-slate-300 text-sm">Type</Label>
                        <Select
                          value={transactionForm.type}
                          onValueChange={(value: any) =>
                            setTransactionForm({ ...transactionForm, type: value })
                          }
                        >
                          <SelectTrigger className="bg-white/5 border-white/10 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent
                            style={{
                              background: "#1a1a24",
                              border: "1px solid rgba(255,255,255,0.1)",
                            }}
                          >
                            {TRANSACTION_TYPES.map((t) => (
                              <SelectItem key={t.value} value={t.value} className="text-white">
                                {t.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Asset</Label>
                        <Select
                          value={transactionForm.asset}
                          onValueChange={(value) =>
                            setTransactionForm({ ...transactionForm, asset: value })
                          }
                        >
                          <SelectTrigger className="bg-white/5 border-white/10 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent
                            style={{
                              background: "#1a1a24",
                              border: "1px solid rgba(255,255,255,0.1)",
                            }}
                          >
                            {assets.slice(0, 8).map((asset) => (
                              <SelectItem key={asset.symbol} value={asset.symbol} className="text-white">
                                {asset.symbol.toUpperCase()}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Amount</Label>
                        <Input
                          type="number"
                          value={transactionForm.amount}
                          onChange={(e) =>
                            setTransactionForm({ ...transactionForm, amount: parseFloat(e.target.value) || 0 })
                          }
                          placeholder="0.00"
                          className="bg-white/5 border-white/10 text-white"
                          step="0.01"
                        />
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Date</Label>
                        <Input
                          type="date"
                          value={transactionForm.date.split("T")[0]}
                          onChange={(e) =>
                            setTransactionForm({ ...transactionForm, date: e.target.value })
                          }
                          className="bg-white/5 border-white/10 text-white"
                        />
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Status</Label>
                        <Select
                          value={transactionForm.status}
                          onValueChange={(value: any) =>
                            setTransactionForm({ ...transactionForm, status: value })
                          }
                        >
                          <SelectTrigger className="bg-white/5 border-white/10 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent
                            style={{
                              background: "#1a1a24",
                              border: "1px solid rgba(255,255,255,0.1)",
                            }}
                          >
                            {TRANSACTION_STATUS.map((s) => (
                              <SelectItem key={s.value} value={s.value} className="text-white">
                                {s.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-slate-300 text-sm">Description</Label>
                        <Input
                          type="text"
                          value={transactionForm.description}
                          onChange={(e) =>
                            setTransactionForm({ ...transactionForm, description: e.target.value })
                          }
                          placeholder="Transaction description"
                          className="bg-white/5 border-white/10 text-white"
                        />
                      </div>

                      <div className="flex gap-2 pt-4">
                        <Button
                          type="submit"
                          className="flex-1"
                          style={{ background: "#2563eb" }}
                        >
                          {editingTxId ? "Update" : "Create"} Transaction
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setTransactionOpen(false)}
                          style={{
                            borderColor: "rgba(255,255,255,0.1)",
                            color: "#94a3b8",
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Transactions Table */}
              {userTransactions.length === 0 ? (
                <div
                  className="rounded-lg p-12 text-center"
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <p className="text-slate-400">No transactions for {selectedUser}</p>
                </div>
              ) : (
                <div
                  className="rounded-lg border overflow-hidden"
                  style={{
                    background: "#1a1a24",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                >
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr
                          style={{
                            borderBottom: "1px solid rgba(255,255,255,0.1)",
                            background: "rgba(0,0,0,0.3)",
                          }}
                        >
                          <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                            Date
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                            Type
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                            Asset
                          </th>
                          <th className="px-6 py-3 text-right text-xs font-semibold text-slate-300">
                            Amount
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-semibold text-slate-300">
                            Description
                          </th>
                          <th className="px-6 py-3 text-center text-xs font-semibold text-slate-300">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {userTransactions.map((tx) => {
                          const typeConfig = TRANSACTION_TYPES.find((t) => t.value === tx.type);
                          const statusConfig = TRANSACTION_STATUS.find((s) => s.value === tx.status);
                          const StatusIcon = statusConfig?.icon;

                          return (
                            <tr
                              key={tx.id}
                              style={{
                                borderBottom: "1px solid rgba(255,255,255,0.05)",
                              }}
                            >
                              <td className="px-6 py-4 text-sm text-slate-300">
                                {new Date(tx.date).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4 text-sm">
                                <span
                                  className="px-2 py-1 rounded text-xs font-semibold text-white"
                                  style={{ background: typeConfig?.color + "20", color: typeConfig?.color }}
                                >
                                  {typeConfig?.label}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-sm font-mono text-white">
                                {tx.asset}
                              </td>
                              <td className="px-6 py-4 text-sm text-right font-semibold text-white">
                                {tx.amount.toFixed(2)}
                              </td>
                              <td className="px-6 py-4 text-sm">
                                <div className="flex items-center gap-2">
                                  {StatusIcon && (
                                    <StatusIcon size={14} style={{ color: statusConfig?.color }} />
                                  )}
                                  <span style={{ color: statusConfig?.color }}>
                                    {statusConfig?.label}
                                  </span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-sm text-slate-400 truncate max-w-xs">
                                {tx.description}
                              </td>
                              <td className="px-6 py-4 text-center">
                                <div className="flex justify-center gap-2">
                                  <button
                                    onClick={() => handleEditTransaction(tx)}
                                    className="p-2 hover:bg-white/10 rounded transition-colors"
                                  >
                                    <Edit2 size={14} className="text-blue-400" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteTransaction(tx.id)}
                                    className="p-2 hover:bg-white/10 rounded transition-colors"
                                  >
                                    <Trash2 size={14} className="text-red-400" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
