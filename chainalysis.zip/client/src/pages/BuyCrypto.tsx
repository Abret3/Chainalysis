/**
 * Chainalysis — Buy Crypto Page
 * Purchase cryptocurrencies with Bitcoin wallet payment
 */

import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCryptoPrices, formatPrice } from "@/hooks/useCryptoPrices";
import { useState, useEffect } from "react";
import { ArrowLeft, Bitcoin, Copy, Check, Clock } from "lucide-react";
import { toast } from "sonner";

const BITCOIN_WALLET = "bc1qatvqtq4dletduhmhhaxyhm4fmmttxkggam2ex7";

// Simple QR code generator using qr-server API
const generateQRCode = (text: string) => {
  return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(text)}`;
};

export default function BuyCrypto() {
  const [, navigate] = useLocation();
  const { assets } = useCryptoPrices();
  const [selectedCrypto, setSelectedCrypto] = useState(() => assets.length > 0 ? assets[0].id : "bitcoin");
  const [amount, setAmount] = useState("");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderDetails, setOrderDetails] = useState<any>(null);

  const selectedAsset = assets.find((a) => a.id === selectedCrypto);
  const cryptoAmount = selectedAsset ? parseFloat(amount || "0") / selectedAsset.price : 0;

  const handleBuy = () => {
    if (!amount) {
      toast.error("Please enter an amount");
      return;
    }
    if (parseFloat(amount) <= 0) {
      toast.error("Amount must be greater than 0");
      return;
    }

    // Create order details
    const order = {
      id: `ORD-${Date.now()}`,
      amount: parseFloat(amount),
      crypto: selectedAsset?.symbol,
      cryptoAmount: cryptoAmount.toFixed(8),
      timestamp: new Date().toLocaleString(),
      status: "pending",
    };

    setOrderDetails(order);
    setOrderPlaced(true);
    setShowPaymentModal(true);
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(BITCOIN_WALLET);
    setCopied(true);
    toast.success("Wallet address copied");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen" style={{ background: "#0d0d14" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          background: "rgba(13,13,20,0.95)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-400" />
          </button>
          <div>
            <h1
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Buy Crypto
            </h1>
            <p className="text-sm text-slate-400">Purchase cryptocurrencies with Bitcoin</p>
          </div>
        </div>
      </header>

      <main className="p-8 max-w-2xl">
        {/* Buy Form */}
        <div
          className="rounded-xl p-8 border"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <h2 className="text-lg font-semibold text-white mb-6">Purchase Amount</h2>

          {/* Crypto Selection */}
          <div className="mb-6">
            <Label className="text-slate-300 text-sm mb-2 block">Select Cryptocurrency</Label>
            <Select value={selectedCrypto || ""} onValueChange={setSelectedCrypto}>
              <SelectTrigger
                className="bg-white/5 border-white/10 text-white"
                style={{ borderColor: "rgba(255,255,255,0.1)" }}
              >
                <SelectValue placeholder="Select a cryptocurrency" />
              </SelectTrigger>
              <SelectContent
                style={{
                  background: "#1a1a24",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                {assets.slice(0, 8).map((asset) => (
                  <SelectItem
                    key={asset.id}
                    value={asset.id}
                    className="text-white"
                  >
                    {asset.name} ({asset.symbol.toUpperCase()}) - {formatPrice(asset.price)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Amount Input */}
          <div className="mb-6">
            <Label className="text-slate-300 text-sm mb-2 block">Amount (USD)</Label>
            <div className="relative">
              <span className="absolute left-4 top-3 text-slate-400">$</span>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount in USD"
                className="pl-8 bg-white/5 border-white/10 text-white"
                min="0"
                step="0.01"
              />
            </div>
          </div>

          {/* Crypto Amount Display */}
          {amount && selectedAsset && (
            <div
              className="p-4 rounded-lg mb-6 border"
              style={{
                background: "rgba(59, 130, 246, 0.05)",
                borderColor: "rgba(59, 130, 246, 0.2)",
              }}
            >
              <p className="text-sm text-slate-400 mb-1">You will receive</p>
              <p className="text-xl font-semibold text-white">
                {cryptoAmount.toFixed(8)} {selectedAsset.symbol.toUpperCase()}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                @ {formatPrice(selectedAsset.price)} per {selectedAsset.symbol.toUpperCase()}
              </p>
            </div>
          )}

          {/* Payment Method Info */}
          <div
            className="p-4 rounded-lg mb-6 border flex items-center gap-3"
            style={{
              background: "rgba(247, 147, 26, 0.05)",
              borderColor: "rgba(247, 147, 26, 0.2)",
            }}
          >
            <Bitcoin size={20} className="text-orange-400" />
            <div>
              <p className="text-sm font-semibold text-white">Bitcoin Payment</p>
              <p className="text-xs text-slate-400">Send BTC to receive your crypto</p>
            </div>
          </div>

          {/* Buy Button */}
          <Button
            onClick={handleBuy}
            className="w-full py-3 text-base font-semibold"
            style={{ background: "#2563eb" }}
            disabled={!amount || parseFloat(amount) <= 0}
          >
            Continue to Payment
          </Button>
        </div>

        {/* Info Section */}
        <div
          className="mt-8 p-6 rounded-lg border"
          style={{
            background: "rgba(59, 130, 246, 0.05)",
            borderColor: "rgba(59, 130, 246, 0.2)",
          }}
        >
          <h3 className="text-sm font-semibold text-white mb-3">How It Works</h3>
          <ol className="space-y-2 text-sm text-slate-300">
            <li className="flex gap-3">
              <span className="text-blue-400 font-semibold">1.</span>
              <span>Select the cryptocurrency you want to buy</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400 font-semibold">2.</span>
              <span>Enter the amount in USD</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400 font-semibold">3.</span>
              <span>Click "Continue to Payment"</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400 font-semibold">4.</span>
              <span>Send Bitcoin to the provided wallet address</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400 font-semibold">5.</span>
              <span>Your crypto will be delivered after confirmation</span>
            </li>
          </ol>
        </div>
      </main>

      {/* Payment Modal */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Bitcoin Payment</DialogTitle>
            <DialogDescription className="text-slate-400">
              Send Bitcoin to complete your purchase
            </DialogDescription>
          </DialogHeader>

          {orderDetails && (
            <div className="space-y-6">
              {/* Order Summary */}
              <div
                className="p-4 rounded-lg border"
                style={{
                  background: "rgba(0,0,0,0.3)",
                  borderColor: "rgba(255,255,255,0.05)",
                }}
              >
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-400">Order ID</span>
                    <span className="text-sm font-mono text-white">{orderDetails.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-400">Amount</span>
                    <span className="text-sm font-semibold text-white">${orderDetails.amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-400">You Will Receive</span>
                    <span className="text-sm font-semibold text-white">
                      {orderDetails.cryptoAmount} {orderDetails.crypto}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-white/10">
                    <span className="text-sm text-slate-400">Status</span>
                    <div className="flex items-center gap-2">
                      <Clock size={14} className="text-yellow-400" />
                      <span className="text-sm font-semibold text-yellow-400">Pending</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* QR Code */}
              <div className="text-center">
                <p className="text-sm text-slate-400 mb-3">Scan to send Bitcoin</p>
                <img
                  src={generateQRCode(BITCOIN_WALLET)}
                  alt="Bitcoin wallet QR code"
                  className="mx-auto rounded-lg"
                />
              </div>

              {/* Wallet Address */}
              <div>
                <p className="text-sm text-slate-400 mb-2">Or copy the wallet address</p>
                <div
                  className="p-3 rounded-lg border flex items-center justify-between"
                  style={{
                    background: "rgba(0,0,0,0.3)",
                    borderColor: "rgba(255,255,255,0.05)",
                  }}
                >
                  <code
                    className="text-xs font-mono text-slate-300 break-all flex-1"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}
                  >
                    {BITCOIN_WALLET}
                  </code>
                  <button
                    onClick={handleCopyAddress}
                    className="flex-shrink-0 ml-2 p-2 hover:bg-white/10 rounded transition-colors"
                  >
                    {copied ? (
                      <Check size={16} className="text-green-400" />
                    ) : (
                      <Copy size={16} className="text-slate-400" />
                    )}
                  </button>
                </div>
              </div>

              {/* Instructions */}
              <div
                className="p-4 rounded-lg border"
                style={{
                  background: "rgba(251, 146, 60, 0.05)",
                  borderColor: "rgba(251, 146, 60, 0.2)",
                }}
              >
                <p className="text-xs text-slate-300">
                  <strong className="text-orange-400">Important:</strong> Send exactly the amount shown above. The transaction will be processed after blockchain confirmation (typically 10-60 minutes).
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={() => setShowPaymentModal(false)}
                  className="flex-1"
                  style={{ background: "#2563eb" }}
                >
                  I've Sent the Bitcoin
                </Button>
                <Button
                  onClick={() => setShowPaymentModal(false)}
                  variant="outline"
                  style={{
                    borderColor: "rgba(255,255,255,0.1)",
                    color: "#94a3b8",
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
