/**
 * Chainalysis — Analytics Page
 * Portfolio analytics, charts, and statistics
 */

import { useLocation } from "wouter";
import { useCryptoPrices } from "@/hooks/useCryptoPrices";
import { ArrowLeft, TrendingUp, TrendingDown, Wallet, Activity } from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export default function Analytics() {
  const [, navigate] = useLocation();
  const { assets } = useCryptoPrices();

  // Mock portfolio data
  const portfolioData = [
    { name: "Bitcoin", value: 45, amount: 2.5 },
    { name: "Ethereum", value: 30, amount: 15.2 },
    { name: "Solana", value: 15, amount: 120 },
    { name: "Others", value: 10, amount: 0 },
  ];

  const chartData = [
    { date: "Mon", price: 42000, volume: 2400 },
    { date: "Tue", price: 43000, volume: 2210 },
    { date: "Wed", price: 41000, volume: 2290 },
    { date: "Thu", price: 45000, volume: 2000 },
    { date: "Fri", price: 47000, volume: 2181 },
    { date: "Sat", price: 46000, volume: 2500 },
    { date: "Sun", price: 48000, volume: 2100 },
  ];

  const COLORS = ["#3b82f6", "#8b5cf6", "#ec4899", "#f59e0b"];

  return (
    <div className="min-h-screen" style={{ background: "#0d0d14" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          background: "rgba(13,13,20,0.95)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-slate-400" />
          </button>
          <div>
            <h1
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Analytics
            </h1>
            <p className="text-sm text-slate-400">Portfolio performance & insights</p>
          </div>
        </div>
      </header>

      <main className="p-8 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: "Total Balance", value: "$0.00", icon: Wallet, change: "+0%" },
            { label: "24h Change", value: "$0.00", icon: TrendingUp, change: "+0%" },
            { label: "7d Change", value: "$0.00", icon: Activity, change: "+0%" },
            { label: "All Time Gain", value: "$0.00", icon: TrendingDown, change: "+0%" },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div
                key={i}
                className="p-6 rounded-lg"
                style={{
                  background: "#1a1a24",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-slate-400 text-sm">{stat.label}</p>
                  <Icon className="text-blue-400" size={18} />
                </div>
                <p
                  className="text-2xl font-bold text-white mb-1"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {stat.value}
                </p>
                <p className="text-xs text-green-400">{stat.change}</p>
              </div>
            );
          })}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Price Chart */}
          <div
            className="lg:col-span-2 p-6 rounded-lg"
            style={{
              background: "#1a1a24",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <h2
              className="text-lg font-semibold text-white mb-4"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Bitcoin Price (7 Days)
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip
                  contentStyle={{
                    background: "#0d0d14",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ fill: "#3b82f6" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Portfolio Pie */}
          <div
            className="p-6 rounded-lg"
            style={{
              background: "#1a1a24",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <h2
              className="text-lg font-semibold text-white mb-4"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Portfolio Allocation
            </h2>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={portfolioData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name} ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {portfolioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "#0d0d14",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Volume Chart */}
        <div
          className="p-6 rounded-lg"
          style={{
            background: "#1a1a24",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <h2
            className="text-lg font-semibold text-white mb-4"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Trading Volume (7 Days)
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  background: "#0d0d14",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="volume" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </main>
    </div>
  );
}
