# Chainalysis — Design Brainstorm

<response>
<probability>0.07</probability>
<text>
## Idea A: "Obsidian Terminal"

**Design Movement:** Neo-brutalist dark terminal aesthetic

**Core Principles:**
- Raw monospace typography mixed with sharp geometric UI
- Deep charcoal blacks with electric blue accent pulses
- Data-first hierarchy: numbers are the visual hero
- Zero decorative noise — every element earns its place

**Color Philosophy:**
- Background: #0a0a0f (near-black with a faint blue undertone)
- Surface cards: #111118
- Accent: #3b82f6 (electric blue) with #22d3ee (cyan) for positive values
- Destructive/negative: #f43f5e
- Text: #e2e8f0 primary, #64748b muted

**Layout Paradigm:**
- Fixed left sidebar (220px) with icon+label nav items
- Main content area with asymmetric card grid
- Sidebar uses a subtle left border accent line for active states

**Signature Elements:**
- Monospace font for all numeric data (JetBrains Mono)
- Thin horizontal rule separators between sections
- Pulsing dot indicators for live price feeds

**Interaction Philosophy:**
- Hover states reveal additional data (price change %)
- Smooth 150ms transitions on all interactive elements

**Animation:**
- Number counters animate on load
- Subtle fade-in stagger for dashboard cards

**Typography System:**
- Display: Space Grotesk Bold (headings)
- Body: Inter 400/500
- Data: JetBrains Mono (all prices, addresses, numbers)
</text>
</response>

<response>
<probability>0.06</probability>
<text>
## Idea B: "Deep Space Finance"

**Design Movement:** Glassmorphism meets institutional dark UI

**Core Principles:**
- Frosted glass cards on deep dark backgrounds
- Gradient accents from indigo to violet
- Layered depth through blur and opacity
- Professional yet futuristic

**Color Philosophy:**
- Background: #050510 (deep navy-black)
- Cards: rgba(255,255,255,0.05) with backdrop-blur
- Accent gradient: from #6366f1 to #8b5cf6
- Green: #10b981 for gains, Red: #ef4444 for losses

**Layout Paradigm:**
- Left sidebar with glowing active state
- Dashboard with hero balance card spanning full width
- Asset list with subtle row hover highlights

**Signature Elements:**
- Gradient border on active sidebar item
- Glowing button effects
- Animated price ticker at top

**Interaction Philosophy:**
- Glass cards lift on hover with shadow expansion
- Button press animations with scale transform

**Animation:**
- Shimmer loading states
- Price value flip animations

**Typography System:**
- Headings: Sora Bold
- Body: DM Sans
- Numbers: Fira Code
</text>
</response>

<response>
<probability>0.05</probability>
<text>
## Idea C: "Midnight Ledger" ← SELECTED

**Design Movement:** Professional dark-mode fintech — Bloomberg Terminal meets modern SaaS

**Core Principles:**
- Authoritative dark palette with precise blue accents
- Typography-driven hierarchy: weight and size do the work
- Structural clarity: sidebar + content grid with clear zones
- Real data prominence: live prices are the visual centerpiece

**Color Philosophy:**
- Background: #0d0d0d (pure near-black)
- Sidebar: #111111 with subtle right border
- Cards: #1a1a1a
- Active/accent: #2563eb (Chainalysis blue)
- Balance card gradient: #1d4ed8 → #3b82f6
- Positive: #22c55e, Negative: #ef4444
- Text: #f1f5f9 primary, #94a3b8 muted

**Layout Paradigm:**
- Fixed 220px left sidebar with icon+text nav
- Right main area: top balance hero + action buttons row + two-column asset/transaction grid
- Sidebar active item has full-width blue background highlight

**Signature Elements:**
- Crypto coin icons with colored circular backgrounds
- Blue gradient balance card (matching reference image)
- Monospace font for all price/balance data

**Interaction Philosophy:**
- Sidebar items highlight on hover with subtle background
- Action buttons (Withdraw/Send/Receive/Exchange) have icon+text layout
- Smooth transitions on all interactive states

**Animation:**
- Price values animate in on page load
- Subtle pulse on live price indicators

**Typography System:**
- Headings: Inter 700 (bold, clean)
- Body: Inter 400/500
- Prices/Numbers: JetBrains Mono (monospace for data precision)
</text>
</response>

## Selected: Idea C — "Midnight Ledger"
